/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Complaints;
import com.upcidcosociety.model.ComplaintsModel;
import com.upcidcosociety.model.ComplaintsReplyModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface ComplaintsService {
       public UpcidResponse saveNewComplaints(ComplaintsModel complaintsModel);
       
       public UpcidResponse getAllComplaints(String username);
       
       public UpcidResponse getComplaintById(Integer id);
       
     public UpcidResponse sentcomplaintReplytoMember(ComplaintsReplyModel complaintsReplyModel);
    
}
