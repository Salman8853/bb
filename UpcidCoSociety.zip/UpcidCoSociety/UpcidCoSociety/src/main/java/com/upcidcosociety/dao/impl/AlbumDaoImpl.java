/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.AlbumDao;
import com.upcidcosociety.dtob.Album;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class AlbumDaoImpl implements AlbumDao{
    
 @Autowired
  private SessionFactory sessionFactory; 
  
     @Override
     public Album addAlbum(Album album){ 
        Session session=sessionFactory.getCurrentSession();
        session.save(album);
        session.flush();
        return album;
     }
     @Override
     public Album getAlbumByTitleName(String titleName){
       try {
       Criteria crite= sessionFactory.getCurrentSession()
                          .createCriteria(Album.class)
                          .add(Restrictions.eq("albumTitle", titleName))
                          .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
                          .setFetchMode("AlbumDetailList", FetchMode.JOIN);
        Album alb=(Album)crite.uniqueResult();
                          return alb;
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
      
     } 
      
   @Override 
   public List<Album> getAlbumList(){
   List<Album> list = sessionFactory.getCurrentSession()
            .createCriteria(Album.class)
            .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
            .setFetchMode("AlbumDetailList", FetchMode.JOIN)
            .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
   
   
   
}
