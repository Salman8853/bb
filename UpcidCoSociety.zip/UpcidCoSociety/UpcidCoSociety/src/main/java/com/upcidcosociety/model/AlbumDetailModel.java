/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
public class AlbumDetailModel {
    private Integer albumdetailId;
    
    private String imageUrl;
    
    private MultipartFile image;

    public AlbumDetailModel() {
    }

    public Integer getAlbumdetailId() {
        return albumdetailId;
    }

    public void setAlbumdetailId(Integer albumdetailId) {
        this.albumdetailId = albumdetailId;
    }

    public MultipartFile getImage() {
        return image;
    }

    public void setImage(MultipartFile image) {
        this.image = image;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

}
