/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.DocumentDetailDao;
import com.upcidcosociety.dtob.DocumentDetail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class DocumentDetailDaoImpl  implements DocumentDetailDao{
    @Autowired
    private SessionFactory  sessionfactory;
    
    @Override
    public DocumentDetail save(DocumentDetail documentdetail){
        Session session=sessionfactory.getCurrentSession();
        session.save(documentdetail);
        session.flush();
        return documentdetail;
    }
}
