/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="complaints")
public class Complaints extends  CommonAttributes implements Serializable{
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "comp_id")
 private Integer compId;
 
 @Column(name="pno_number")
 private String pnotNumber; 
    
  @Column(name="mobile_number")
 private String mobileNumber; 

@Column(name="customer_name")
 private String customerName; 

@Column(name="email_id")
 private String emailId; 

@Column(name="pin_code")
 private String pinCode; 

@Column(name="remark")
 private String remark;

@ManyToOne
@JoinColumn(name = "comp_request", referencedColumnName = "comp_request_id")
private ComplaintsRequestMaster compRequest;

@ManyToOne
@JoinColumn(name = "comp_category", referencedColumnName = "comp_category_id")
private ComplaintsCategoryMaster compCategory;

    public Complaints() {
        
    }

    

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public String getPnotNumber() {
        return pnotNumber;
    }

    public void setPnotNumber(String pnotNumber) {
        this.pnotNumber = pnotNumber;
    }

   

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public ComplaintsRequestMaster getCompRequest() {
        return compRequest;
    }

    public void setCompRequest(ComplaintsRequestMaster compRequest) {
        this.compRequest = compRequest;
    }

    public ComplaintsCategoryMaster getCompCategory() {
        return compCategory;
    }

    public void setCompCategory(ComplaintsCategoryMaster compCategory) {
        this.compCategory = compCategory;
    }

    
}
