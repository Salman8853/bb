/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.model.ChangePasswordModel;
import com.upcidcosociety.service.ChangePasswordService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class AdminController {

    @Autowired
    private ChangePasswordService changePasswordService; 
    
    
   @RequestMapping("/changepassword")
    public String changeAdminPassword(ModelMap map,Principal principal) {
        map.addAttribute("changePassword_Form",new ChangePasswordModel());
        return "changepassword";
    }
    
     @RequestMapping("/getadminvalue/{currentpassword}")
    public @ResponseBody String changeAdminByAjax(@PathVariable String currentpassword, ModelMap map,Principal principal) {
      UpcidResponse response=changePasswordService.getadminByadminName(currentpassword,principal.getName());
         if(response.getStatus()==HttpStatus.OK){
         
         return "{\"result\":\"success\"}";
         }else{
         return "{\"result\":\"failed\"}";
          } 
    }
    
     @RequestMapping(value = "/passwordchanged",method = RequestMethod.POST)
    public String changeAdminPassword(@ModelAttribute("changePassword_Form")ChangePasswordModel changePasswordModel,BindingResult result,ModelMap map,HttpServletRequest request,Principal principal) {
     UpcidResponse upcidResponse = null;
        if(result.hasErrors()){
         
         
         }else{
            
             upcidResponse=changePasswordService.changePassword(changePasswordModel, request.getRemoteAddr(), principal.getName());
             
          } 
             request.getSession().setAttribute("msg", upcidResponse.getMessage());
          
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }

        return "redirect:/upcid/changepassword";
    }
    
    
  }
  
