/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dao.PostingDao;
import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.model.PostingModel;
import com.upcidcosociety.service.PostingService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class PostingServiceImpl implements PostingService{
     private static final Logger logger = LoggerFactory.getLogger(PostingServiceImpl.class); 
     
    @Autowired 
    private PostingDao postingDao;
    
    @Autowired
    private MemberAccountDao memberAccountDao;
    
    @Override
    public UpcidResponse addPosting(Posting posting,String remoteaddress,String username){
        UpcidResponse<Posting> response=new UpcidResponse();
        try {
            Posting  pt=null;
          if(posting!=null && posting.getPosting()!=null && posting.getPosting().trim().length()>0){
              Posting psting = postingDao.checkPostingByName(posting.getPosting());
                if(psting!=null && psting.getId()>0){
                 response.setStatus(HttpStatus.CONFLICT);
                 response.setMessage("Record already exist");
                 response.setData(psting);
                  return response;
                }
                 pt= new Posting();
                 pt.setPosting(posting.getPosting());
                 pt.setIpAddress(remoteaddress);
                 pt.setCreatedBy(username);
                 pt.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                 pt.setModifiedBy(username);
                 pt.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                 Posting  pst=postingDao.addPosting(pt);
                if(pst!=null && pst.getId()!=null && pst.getId()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(pst);
                }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(pst);
                }
                
          }else{
            response.setStatus(HttpStatus.NOT_FOUND);
            response.setMessage("Plaese enter mandatory fields!");
            response.setData(null);
          }
      } catch (Exception e) {
          
         response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when saving new Posting");
         logger.info("Exception when saving new Posting:"+e);
      }
        
      return response;
    
    }
    
   @Override
    public UpcidResponse updatePosting(Posting posting,String remoteaddress,String username){
      UpcidResponse response=new UpcidResponse();
      Posting pst=null;
       try{
           if(posting!=null && posting.getId()!=null && posting.getId()>0 && posting.getPosting()!=null && posting.getPosting().trim().length()>0){
               pst = postingDao.checkPostingByidAndPostingName(posting.getId(),posting.getPosting());
               if (pst != null) {
                   response.setStatus(HttpStatus.CONFLICT);
                   response.setMessage("Record already exist");
                   response.setData(pst);
                   return response;
               }
               pst = postingDao.getPostingByid(posting.getId());
               if(pst!=null && pst.getId()>0){
               pst.setPosting(posting.getPosting());
               pst.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
               pst.setIpAddress(remoteaddress);
               pst.setModifiedBy(username);
               Posting psting= postingDao.updatePosting(pst);
                if (psting != null && psting.getId() > 0) {
                   response.setStatus(HttpStatus.OK);;
                   response.setMessage("Record update!");
                   response.setData(psting);
               } else {
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record updation failed!");
                   response.setData(psting);
               }
             }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(pst);
                 }
           }else{
               response.setStatus(HttpStatus.NOT_FOUND);
               response.setMessage("Plaese enter mandatory fields!");
               response.setData(null);
           }
           
        }catch(Exception e){
         response= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving update category");
         logger.info("Exception while update category:"+e);
        }
       return response; 
     
    }
     @Override
    public UpcidResponse getAllPosting(String userName){
        UpcidResponse<List<PostingModel>> response = new UpcidResponse();
        try {
            PostingModel postingModel = null;
            List<PostingModel> postingModelList = new ArrayList<>();
            List<Integer> postingIdList = new ArrayList<>();
            List<Posting> rankList = memberAccountDao.getallDistinctPostingListByCriteria();
            if (rankList != null && rankList.size() > 0) {
                for (Posting posting : rankList) {

                    postingIdList.add(posting.getId());
                }
            }
          List<Posting>pstlst=postingDao.getAllPosting();
            if (pstlst != null && pstlst.size() > 0) {
                for (Posting post : pstlst) {
                    postingModel = new PostingModel();
                    postingModel.setId(post.getId());
                    postingModel.setPosting(post.getPosting());
                    if (postingIdList != null && postingIdList.contains(post.getId())) {
                        postingModel.setInUse(UpcidConstants.IN_USE);

                    } else {
                        postingModel.setInUse(UpcidConstants.IS_Delete);
                    }
                    postingModelList.add(postingModel);
                }
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(postingModelList);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(postingModelList);
            }
        } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll Posting");
             logger.info("Exception occured when getAll Posting:" + e);
              e.printStackTrace();
        }
        return response; 
    }
    
   @Override
    public UpcidResponse getAllPostingforMember(String userName){
    
      UpcidResponse<List<Posting>> response=new UpcidResponse();
         try {
             List<Posting>pstlst=postingDao.getAllPosting();
             if(pstlst!=null && pstlst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(pstlst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record Not Found");
                response.setData(pstlst);
             } 
         } catch (Exception e) {
              response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll Posting");
             logger.info("Exception occured when getAll Posting:" + e);
              e.printStackTrace();
         }
         return response;
    
    }
    
    @Override
    public UpcidResponse getPostingById(Integer id,String userName){
     UpcidResponse<Posting> response=new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Posting posting = postingDao.getPostingByid(id);
                if (posting != null && posting.getId()> 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("");
                    response.setData(posting);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found");
                    response.setData(posting);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("posting id not found");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get posting by id");
            logger.info("Exception occured when get posting by id:" + e);
            e.printStackTrace();
        }
        return response; 
    }
    @Override
    public UpcidResponse softDeletePostingById(Integer id,String userName){
     UpcidResponse<Posting> response=new UpcidResponse();
          try {
              if (id != null && id > 0){
               Posting posting = postingDao.getPostingByid(id);
               if(posting!=null && posting.getId()!=null && posting.getId()>0){
                   
                 posting.setIsDeleted(Boolean.TRUE);
                 posting.setModifiedBy(userName);
                 posting.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                 Posting post= postingDao.updatePosting(posting);
                 if(post!=null && post.getId()!=null && post.getId()>0){
                   response.setStatus(HttpStatus.OK);
                   response.setMessage("record deleted");
                   response.setData(post);
                 }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("record deletion failed");
                   response.setData(post);
                  }
               }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("record not found");
                response.setData(posting);
                }
              }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("posting id not found");
                response.setData(null);
              }
             
         } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when delete posting by id");
            logger.info("Exception occured when delete posting by id:" + e);
            e.printStackTrace(); 
         }
         return response; 
    }
}
