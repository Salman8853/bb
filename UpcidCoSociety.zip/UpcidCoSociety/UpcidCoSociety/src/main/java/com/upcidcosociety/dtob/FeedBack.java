/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "FeedBack")
public class FeedBack extends  CommonAttributes implements Serializable {
    
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "comp_id")
 private Integer compId;
 
 @Column(name="name")
 private String name; 
    
  @Column(name="email_id")
 private String emailId; 


 @Column(name="address")
 private String address; 
 
 @Column(name="contact_number")
 private String contactNumber; 
 
 @Column(name="city")
 private String city;

@Column(name="state")
 private String state; 

 @Lob
 @Column(name="query_detail")
 private String queryDetail; 

    public FeedBack() {

    }

    
    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getQueryDetail() {
        return queryDetail;
    }

    public void setQueryDetail(String queryDetail) {
        this.queryDetail = queryDetail;
    }

    @Override
    public String toString() {
        return "FeedBack{" + "compId=" + compId + ", name=" + name + ", emailId=" + emailId + ", address=" + address + ", contactNumber=" + contactNumber + ", city=" + city + ", state=" + state + ", queryDetail=" + queryDetail + '}';
    }
    
}
