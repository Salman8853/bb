/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.model.AlbumModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface PhotoGalaryService {
     public UpcidResponse addPhotoGalary(AlbumModel albumModel,String remoteaddress,String username);
     
     public UpcidResponse getallAlbumList(String username);
     
     public UpcidResponse getgalaryListByalbumTitle(String albumTitle,String username);
     
     public UpcidResponse deteteGalaryimage(Integer albumTitle,String username);
    
    
}
