/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.RdentryDetailDao;
import com.upcidcosociety.dtob.RdentryDetail;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RdentryDetailDaoImpl implements RdentryDetailDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public RdentryDetail saveNewRdentryDetails(RdentryDetail rdentryDetail) {
        Session session = sessionFactory.getCurrentSession();
        session.save(rdentryDetail);
        session.flush();
        return rdentryDetail;

    }
     @Override
     public RdentryDetail updatenewrdentrydetails(RdentryDetail rdentrydetail){
     try {
           Session session=sessionFactory.getCurrentSession();
           session.update(rdentrydetail);
           session.flush();
            return rdentrydetail;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
     }
    @Override
    public RdentryDetail getRdentryDetailsByrdSerialNo(Integer rdSerialNo){
       try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM RdentryDetail rdedtls WHERE rdedtls.rdSerialNo=:rdSerialNo";
            Query query = session.createQuery(hql);
            query.setParameter("rdSerialNo", rdSerialNo);
            List<RdentryDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<RdentryDetail> getAllRdentryDetailsofMember(Integer rdAccNo) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM RdentryDetail rdedtls WHERE rdedtls.rdDetails.rdAccNo=:rdAccNo";
            Query query = session.createQuery(hql);
            query.setParameter("rdAccNo", rdAccNo);
            List<RdentryDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public RdentryDetail getRdentryDetailByrdaccnoAndrdserialno(Integer rdAccNo,Integer rdserialNo){
         try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM RdentryDetail rdedtls WHERE rdedtls.rdSerialNo=:rdserialNo  AND  rdedtls.rdDetails.rdAccNo=:rdAccNo";
            Query query = session.createQuery(hql);
            query.setParameter("rdserialNo", rdserialNo);
            query.setParameter("rdAccNo", rdAccNo);
            List<RdentryDetail> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
