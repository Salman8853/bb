/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberShareDetailDao;
import com.upcidcosociety.dao.MemberShareDetailMonthWiseDao;
import com.upcidcosociety.dao.MemberShareRequestDao;
import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.MemberShareDetailMonthWise;
import com.upcidcosociety.dtob.MemberShareRequest;
import com.upcidcosociety.service.MemberShareJobService;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class MemberShareJobServiceImpl implements MemberShareJobService {

    private static final Logger logger = LoggerFactory.getLogger(MemberShareJobServiceImpl.class);

    @Autowired
    private MemberShareDetailDao membersharedetaildao;

    @Autowired
    private MemberShareDetailMonthWiseDao membersharedetailmonthwisedao;

    @Autowired
    private MemberShareRequestDao membersharerequestdao;

    @Override
    public void memberShareJobmonthWise() {
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            cal.set(Calendar.HOUR, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date sdate = cal.getTime();
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date edate = cal.getTime();
             Map<Integer, List<MemberShareRequest>> requestMap=null;
            List<MemberShareRequest> memsharelst = membersharerequestdao.getAllmemberRequestListforcrntmonth(sdate, edate);
            if(memsharelst!=null && !memsharelst.isEmpty()){
             requestMap = new HashMap<Integer, List<MemberShareRequest>>();
            for (MemberShareRequest request : memsharelst) {
                if (requestMap.containsKey(request.getMemberId())) {
                    List<MemberShareRequest> memshrlst = requestMap.get(request.getMemberId());
                    memshrlst.add(request);
                } else {
                    List<MemberShareRequest> lst = new ArrayList<>();
                    lst.add(request);
                    requestMap.put(request.getMemberId(), lst);
                }
            }
        }
            List<MemberShareDetail> list = membersharedetaildao.getAllmeberShareDetail();
            if (list != null && list.size() > 0) {
                for (MemberShareDetail membersharedetail : list) {
                    
                     Double totalshare = 0.0;
                     if(requestMap!=null && !requestMap.isEmpty()){
                    if (requestMap.containsKey(membersharedetail.getMemberDetail().getMemberId())) {
                        List<MemberShareRequest> memshrlst = requestMap.get(membersharedetail.getMemberDetail().getMemberId());
                        for (MemberShareRequest membersharerequest : memshrlst) {
                            DateTime date = new DateTime();
                            String monthname = date.monthOfYear().getAsText();
                            Integer year = null;
                            if (monthname.equalsIgnoreCase("January") || monthname.equalsIgnoreCase("February") || monthname.equalsIgnoreCase("March")) {
                                year = date.getYear() - 1;
                            } else {
                                year = date.getYear();
                            }
                            List<String> requestmonthnamelst = new ArrayList<>();
                            List<MemberShareDetailMonthWise> membersharemonthwiselist = membersharedetailmonthwisedao.getAllMemberShareDetailMonthWiseBymsdIdAndfinyear(membersharedetail.getMsdId(), year);
                            for(MemberShareDetailMonthWise monthwise:membersharemonthwiselist){
                               requestmonthnamelst.add(monthwise.getMonth());
                                totalshare = totalshare + monthwise.getAmount();
                             }
                             MemberShareDetailMonthWise membersharedetailmonthwise = null;
                            if(requestmonthnamelst!=null && !requestmonthnamelst.isEmpty() && !requestmonthnamelst.contains(monthname)){
                            membersharedetailmonthwise = new MemberShareDetailMonthWise();
                            membersharedetailmonthwise.setAmount(membersharerequest.getAmount());
                            membersharedetailmonthwise.setMonth(monthname);
                            membersharedetailmonthwise.setFinyear(year);
                            membersharedetailmonthwise.setDate(date.toDate());
                            membersharedetailmonthwise.setMemberShareDetail(membersharedetail);
                            membersharedetailmonthwisedao.saveNewMemberShareDetailMonthWise(membersharedetailmonthwise);
                            
                           totalshare = totalshare + membersharedetail.getSrdAmount();
                          }  
                       }
                    }
                    } else {
                        DateTime date = new DateTime();
                        String monthname = date.monthOfYear().getAsText();
                        Integer year = null;
                        if (monthname.equalsIgnoreCase("January") || monthname.equalsIgnoreCase("February") || monthname.equalsIgnoreCase("March")) {
                            year = date.getYear() - 1;
                        } else {
                            year = date.getYear();
                        }
                        List<MemberShareDetailMonthWise> membersharemonthwiselist = membersharedetailmonthwisedao.getAllMemberShareDetailMonthWiseBymsdIdAndfinyear(membersharedetail.getMsdId(), year);
                        List<String> depositemonth = new ArrayList<>();
                        if (membersharemonthwiselist != null && membersharemonthwiselist.size() > 0) {
                            for (MemberShareDetailMonthWise membersharedetailmonthwise : membersharemonthwiselist) {
                                depositemonth.add(membersharedetailmonthwise.getMonth());
                                totalshare = totalshare + membersharedetailmonthwise.getAmount();
                            }
                        }
                        MemberShareDetailMonthWise membersharedetailmonthwise = null;
                        if (depositemonth != null && !depositemonth.contains(monthname)) {
                            membersharedetailmonthwise = new MemberShareDetailMonthWise();
                            membersharedetailmonthwise.setAmount(membersharedetail.getSrdAmount());
                            membersharedetailmonthwise.setMonth(monthname);
                            membersharedetailmonthwise.setFinyear(year);
                            membersharedetailmonthwise.setDate(date.toDate());
                            membersharedetailmonthwise.setMemberShareDetail(membersharedetail);
                            membersharedetailmonthwisedao.saveNewMemberShareDetailMonthWise(membersharedetailmonthwise);
                            totalshare = totalshare + membersharedetail.getSrdAmount();
                        }
                    }
//                        Double getshare = membersharedetail.getTotalShare() != null ? membersharedetail.getTotalShare() : 0.0;
                        totalshare = totalshare +membersharedetail.getShareOpeningBalance();
                        membersharedetail.setTotalShare(totalshare);
                        membersharedetaildao.savemeberShareDetail(membersharedetail);

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Finished");
    }

}
