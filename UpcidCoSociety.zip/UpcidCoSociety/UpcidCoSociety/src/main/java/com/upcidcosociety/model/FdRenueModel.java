/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class FdRenueModel {
    
    private String pnonumber;
   
    private String fdaccno;
   
    private String agegroup;
    
    private Double renueableAmount;
    
    private String startdate;
    
    private String maturitydate;
    
    private Double maturityamountr;
    
    private Integer period;
    
    private Double fdpartrate;
    
    private Double fdfullrate;

    public Double getRenueableAmount() {
        return renueableAmount;
    }

    public void setRenueableAmount(Double renueableAmount) {
        this.renueableAmount = renueableAmount;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getMaturitydate() {
        return maturitydate;
    }

    public void setMaturitydate(String maturitydate) {
        this.maturitydate = maturitydate;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public Double getFdpartrate() {
        return fdpartrate;
    }

    public void setFdpartrate(Double fdpartrate) {
        this.fdpartrate = fdpartrate;
    }

    public Double getFdfullrate() {
        return fdfullrate;
    }

    public void setFdfullrate(Double fdfullrate) {
        this.fdfullrate = fdfullrate;
    }

    public String getPnonumber() {
        return pnonumber;
    }

    public void setPnonumber(String pnonumber) {
        this.pnonumber = pnonumber;
    }

    public String getFdaccno() {
        return fdaccno;
    }

    public void setFdaccno(String fdaccno) {
        this.fdaccno = fdaccno;
    }

    public String getAgegroup() {
        return agegroup;
    }

    public void setAgegroup(String agegroup) {
        this.agegroup = agegroup;
    }

    public Double getMaturityamountr() {
        return maturityamountr;
    }

    public void setMaturityamountr(Double maturityamountr) {
        this.maturityamountr = maturityamountr;
    }
 
}
