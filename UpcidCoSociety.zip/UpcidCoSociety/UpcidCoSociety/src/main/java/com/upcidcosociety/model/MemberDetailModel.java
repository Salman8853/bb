/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import com.upcidcosociety.dtob.Users;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */


public class MemberDetailModel {

    private Integer memberId;

    private String memberName;


    private String dateOfBirth;
    
    private String dateofappoint;
    
    private String dateOfRetirement;

    private String pnoNumber;

    private String fatherName;

    private String mobileNumber;
    
    private String email;
    
    private String presentAddress;
    
    private String permanentAddress ; 
    
 
    private String profileulr ;
     
    private String signurl ;
      
    private String accountOpenFormurl ;
    
    private String gpfornpanumber;

    private String aadharnumber;

    private String pannumber;
    
    private String accountOpeningDate; 
    
    private String accountstartDate;
    
    private String memberaccountNumber;
    
    private Boolean desclaimer;
    
    private String status;
    
    

    private MemberAccountModel memberAccountmodel;
    
    
    private Users users;
    
    private List<NomineeModel> nomineemodel;
    
    private List<MemberWitnessModel> memberwitnessmodel;
  
    private MultipartFile memberphoto;
    
    private MultipartFile membersignature;
     
    private MultipartFile memberAccountOpenningform;

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateofappoint() {
        return dateofappoint;
    }

    public void setDateofappoint(String dateofappoint) {
        this.dateofappoint = dateofappoint;
    }

    
    
    public String getDateOfRetirement() {
        return dateOfRetirement;
    }

    public void setDateOfRetirement(String dateOfRetirement) {
        this.dateOfRetirement = dateOfRetirement;
    }

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getProfileulr() {
        return profileulr;
    }

    public void setProfileulr(String profileulr) {
        this.profileulr = profileulr;
    }

    public String getSignurl() {
        return signurl;
    }

    public void setSignurl(String signurl) {
        this.signurl = signurl;
    }

    public String getAccountOpenFormurl() {
        return accountOpenFormurl;
    }

    public void setAccountOpenFormurl(String accountOpenFormurl) {
        this.accountOpenFormurl = accountOpenFormurl;
    }
    
    
    
    public MemberAccountModel getMemberAccountmodel() {
        return memberAccountmodel;
    }

    public void setMemberAccountmodel(MemberAccountModel memberAccountmodel) {
        this.memberAccountmodel = memberAccountmodel;
    }

    public List<NomineeModel> getNomineemodel() {
        return nomineemodel;
    }

    public void setNomineemodel(List<NomineeModel> nomineemodel) {
        this.nomineemodel = nomineemodel;
    }

    public List<MemberWitnessModel> getMemberwitnessmodel() {
        return memberwitnessmodel;
    }

    public void setMemberwitnessmodel(List<MemberWitnessModel> memberwitnessmodel) {
        this.memberwitnessmodel = memberwitnessmodel;
    }

   
    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public MultipartFile getMemberphoto() {
        return memberphoto;
    }

    public void setMemberphoto(MultipartFile memberphoto) {
        this.memberphoto = memberphoto;
    }

    public MultipartFile getMembersignature() {
        return membersignature;
    }

    public void setMembersignature(MultipartFile membersignature) {
        this.membersignature = membersignature;
    }

    public MultipartFile getMemberAccountOpenningform() {
        return memberAccountOpenningform;
    }

    public void setMemberAccountOpenningform(MultipartFile memberAccountOpenningform) {
        this.memberAccountOpenningform = memberAccountOpenningform;
    }

    public String getGpfornpanumber() {
        return gpfornpanumber;
    }

    public void setGpfornpanumber(String gpfornpanumber) {
        this.gpfornpanumber = gpfornpanumber;
    }

    public String getAadharnumber() {
        return aadharnumber;
    }

    public void setAadharnumber(String aadharnumber) {
        this.aadharnumber = aadharnumber;
    }

    public String getPannumber() {
        return pannumber;
    }

    public void setPannumber(String pannumber) {
        this.pannumber = pannumber;
    }

    public String getAccountOpeningDate() {
        return accountOpeningDate;
    }

    public void setAccountOpeningDate(String accountOpeningDate) {
        this.accountOpeningDate = accountOpeningDate;
    }
    
    
    public Boolean getDesclaimer() {
        return desclaimer;
    }

    public void setDesclaimer(Boolean desclaimer) {
        this.desclaimer = desclaimer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    public String getAccountstartDate() {
        return accountstartDate;
    }

    public void setAccountstartDate(String accountstartDate) {
        this.accountstartDate = accountstartDate;
    }

    public String getMemberaccountNumber() {
        return memberaccountNumber;
    }

    public void setMemberaccountNumber(String memberaccountNumber) {
        this.memberaccountNumber = memberaccountNumber;
    }
    
    
}
