/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.UsersDao;
import com.upcidcosociety.dtob.Users;
import com.upcidcosociety.model.ChangePasswordModel;
import com.upcidcosociety.service.ChangePasswordService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class ChangePasswordServiceImpl implements ChangePasswordService{
  private static final Logger logger = LoggerFactory.getLogger(ChangePasswordServiceImpl.class);
  
 @Autowired
 private UsersDao userDao;
 
 @Autowired
 private  BCryptPasswordEncoder passwordEncoder;
    
    @Override
     public UpcidResponse changePassword(ChangePasswordModel changePasswordModel,String remoteaddress,String username){
           UpcidResponse<Users> upcidResponse=new UpcidResponse();
            try {
                if(changePasswordModel!=null && changePasswordModel.getCurrentPassword()!=null && changePasswordModel.getCurrentPassword().trim().length()>0){
               Users users=userDao.getAdminByUserName(username);
                if(users!=null && passwordEncoder.matches(changePasswordModel.getCurrentPassword(), users.getPassword())){
                      users.setModifiedBy(username);
                      users.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                      users.setIpAddress(remoteaddress);
                      users.setPassword(passwordEncoder.encode(changePasswordModel.getNewPassword()));
                      Users usr=  userDao.updateUsers(users);
                      if(usr!=null && usr.getUserid()!=null && usr.getUserid()>0){
                      
                      upcidResponse.setStatus(HttpStatus.OK);
                      upcidResponse.setMessage("Your password changed successfully!");
                      upcidResponse.setData(users);  
                          
                      }else{
                      upcidResponse.setStatus(HttpStatus.NOT_FOUND);
                      upcidResponse.setMessage("password change failed");
                      upcidResponse.setData(users);
                      
                       }
                
                }else{
                    upcidResponse.setStatus(HttpStatus.NOT_FOUND);
                    upcidResponse.setMessage("Sorry! Record not found");
                    upcidResponse.setData(users);
                 }
                
            }else{
                    upcidResponse.setStatus(HttpStatus.NOT_FOUND);
                    upcidResponse.setMessage("please fill mendatory fields");
                    upcidResponse.setData(null);
           
            }
  
        } catch (Exception e) {
           upcidResponse= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when changing admin password");
           logger.info("Exception when changing admin password:"+e);
            
        }
         
      return upcidResponse;
     } 
     
     @Override
     public UpcidResponse getadminByadminName(String currentpassword,String username){
       UpcidResponse<String> upcidResponse=new UpcidResponse();
         try {
             
           Users users=userDao.getAdminByUserName(username);
             if(users!=null && users.getUserid()!=null && users.getUserid()>0){
                 if(currentpassword!=null && passwordEncoder.matches(currentpassword, users.getPassword())){
                 upcidResponse.setStatus(HttpStatus.OK);
                 upcidResponse.setMessage("record found!");
                 upcidResponse.setData("True"); 
                 
                  }else{
                 upcidResponse.setStatus(HttpStatus.NOT_FOUND);
                 upcidResponse.setMessage("record not found!");
                 upcidResponse.setData("False"); 
                 }
             
              }
         } catch (Exception e) {
            upcidResponse= new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting admin password");
            logger.info("Exception when getting admin password:"+e);  
         }
      return upcidResponse;
     }
}
