/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.SoftwareSetings;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface SoftwareSetingsService {
    
    public UpcidResponse saveSoftwareSetings(SoftwareSetings softwareSetingsReq,String userName);
    
}
