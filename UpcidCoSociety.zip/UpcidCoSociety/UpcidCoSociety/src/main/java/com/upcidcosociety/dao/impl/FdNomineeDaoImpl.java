/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.FdNomineeDao;
import com.upcidcosociety.dtob.FdNominee;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class FdNomineeDaoImpl implements FdNomineeDao{
  @Autowired
  private SessionFactory sessionFactory; 
  @Override
   public FdNominee savefdnominee(FdNominee fdnominee){
        Session session=sessionFactory.getCurrentSession();
        session.save(fdnominee);
        session.flush();
        return fdnominee;
    } 
   
   @Override
   public List<FdNominee> getfdnomineelist(String fdaccno){
     try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM FdNominee n WHERE  n.fddetails.fdAccNo=:fdaccno";
               Query query = session.createQuery(hql);
               query.setParameter("fdaccno",fdaccno);
               List<FdNominee>results = query.list();
                if(results!=null && results.size()>0){
                  return results;
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
     
   
    } 
   
    
}
