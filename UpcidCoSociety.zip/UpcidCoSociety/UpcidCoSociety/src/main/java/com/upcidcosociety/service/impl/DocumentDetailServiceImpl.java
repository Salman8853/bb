/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.DocumentDetailDao;
import com.upcidcosociety.dtob.DocumentDetail;
import com.upcidcosociety.service.DocumentDetailService;
import com.upcidcosociety.util.UpcidResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class DocumentDetailServiceImpl implements DocumentDetailService{
   private static final Logger logger = LoggerFactory.getLogger(DocumentDetailServiceImpl.class);
  
 @Autowired
 private DocumentDetailDao documentdetaildao;
    
    
// @Override
// public UpcidResponse< DocumentDetail>savedocumentDetails(DocumentDetail documentdetail){
//      try {
//         
//     } catch (Exception e) {
//         
//     }
//     
//     
// }
    
    
}
