/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class FdCertificateModel {
    
   private String memberName;
   
   private String rankName;
   
   private String pnoNumber;
   
   private String fdAccNo;
   
   private String bookNo;
   
   private String fdCertificateNo;
   
   private String fdLedgerNo;
   
   private String recieptNo;
   
   private String dateOfOpenning;
   
   private String dateOfMaturity;
   
   private Double depositeAmount;
   
   private String depositeAmountinWord;
   
   private Double maturityAmount;
   
   private Integer period;
   
   private Double fdrate;

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public String getFdAccNo() {
        return fdAccNo;
    }

    public void setFdAccNo(String fdAccNo) {
        this.fdAccNo = fdAccNo;
    }

   
   
    public String getBookNo() {
        return bookNo;
    }

    public void setBookNo(String bookNo) {
        this.bookNo = bookNo;
    }

    public String getFdCertificateNo() {
        return fdCertificateNo;
    }

    public void setFdCertificateNo(String fdCertificateNo) {
        this.fdCertificateNo = fdCertificateNo;
    }

    public String getFdLedgerNo() {
        return fdLedgerNo;
    }

    public void setFdLedgerNo(String fdLedgerNo) {
        this.fdLedgerNo = fdLedgerNo;
    }

    public String getRecieptNo() {
        return recieptNo;
    }

    public void setRecieptNo(String recieptNo) {
        this.recieptNo = recieptNo;
    }

    public String getDateOfOpenning() {
        return dateOfOpenning;
    }

    public void setDateOfOpenning(String dateOfOpenning) {
        this.dateOfOpenning = dateOfOpenning;
    }

    public String getDateOfMaturity() {
        return dateOfMaturity;
    }

    public void setDateOfMaturity(String dateOfMaturity) {
        this.dateOfMaturity = dateOfMaturity;
    }

    public Double getDepositeAmount() {
        return depositeAmount;
    }

    public void setDepositeAmount(Double depositeAmount) {
        this.depositeAmount = depositeAmount;
    }

    public Double getMaturityAmount() {
        return maturityAmount;
    }

    public void setMaturityAmount(Double maturityAmount) {
        this.maturityAmount = maturityAmount;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public String getDepositeAmountinWord() {
        return depositeAmountinWord;
    }

    public void setDepositeAmountinWord(String depositeAmountinWord) {
        this.depositeAmountinWord = depositeAmountinWord;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public Double getFdrate() {
        return fdrate;
    }

    public void setFdrate(Double fdrate) {
        this.fdrate = fdrate;
    }
    
    
   
}
