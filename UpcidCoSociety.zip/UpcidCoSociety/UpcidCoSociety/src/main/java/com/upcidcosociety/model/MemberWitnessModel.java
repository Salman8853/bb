/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
public class MemberWitnessModel {
    
    private Integer wId;

    private String wName;

    private String wRank;
    
    private String wPno;
    
    private String wAddress;
    
    private String wmobilenumber;
    
    private String wSignUrl;
    
   private MultipartFile wSign;

    public MemberWitnessModel() {
        
    }

    public Integer getwId() {
        return wId;
    }

    public void setwId(Integer wId) {
        this.wId = wId;
    }

    public String getwName() {
        return wName;
    }

    public void setwName(String wName) {
        this.wName = wName;
    }

    public String getwRank() {
        return wRank;
    }

    public void setwRank(String wRank) {
        this.wRank = wRank;
    }

    public String getwPno() {
        return wPno;
    }

    public void setwPno(String wPno) {
        this.wPno = wPno;
    }

    public String getwAddress() {
        return wAddress;
    }

    public void setwAddress(String wAddress) {
        this.wAddress = wAddress;
    }

    public String getWmobilenumber() {
        return wmobilenumber;
    }

    public void setWmobilenumber(String wmobilenumber) {
        this.wmobilenumber = wmobilenumber;
    }

    public String getwSignUrl() {
        return wSignUrl;
    }

    public void setwSignUrl(String wSignUrl) {
        this.wSignUrl = wSignUrl;
    }

    public MultipartFile getwSign() {
        return wSign;
    }

    public void setwSign(MultipartFile wSign) {
        this.wSign = wSign;
    }
}
