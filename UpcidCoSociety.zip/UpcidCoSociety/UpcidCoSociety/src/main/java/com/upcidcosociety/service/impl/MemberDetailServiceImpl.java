/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.upcidcosociety.dao.CategoryDao;
import com.upcidcosociety.dao.ManageLoanDao;
import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dao.MemberShareDetailDao;
import com.upcidcosociety.dao.MemberShareDetailMonthWiseDao;
import com.upcidcosociety.dao.MemberWitnessDao;
import com.upcidcosociety.dao.NomineeDao;
import com.upcidcosociety.dao.PaymentModeDao;
import com.upcidcosociety.dao.PostingDao;
import com.upcidcosociety.dao.RankDao;
import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dao.RoleDao;
import com.upcidcosociety.dao.SectorDao;
import com.upcidcosociety.dao.UserRoleDao;
import com.upcidcosociety.dao.UsersDao;
import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.dtob.LoanDetails;
import com.upcidcosociety.dtob.MemberAccount;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.MemberShareDetailMonthWise;
import com.upcidcosociety.dtob.MemberWitness;
import com.upcidcosociety.dtob.Nominee;
import com.upcidcosociety.dtob.PaymentMode;
import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.dtob.RdDetails;
import com.upcidcosociety.dtob.Role;
import com.upcidcosociety.dtob.Sector;
import com.upcidcosociety.dtob.UserRole;
import com.upcidcosociety.dtob.Users;
import com.upcidcosociety.model.MemberAccountModel;
import com.upcidcosociety.model.MemberDetailModel;
import com.upcidcosociety.model.MemberDetailModelforRd;
import com.upcidcosociety.model.MemberDetailResponseModelForLoan;
import com.upcidcosociety.model.MemberWitnessModel;
import com.upcidcosociety.model.NomineeModel;
import com.upcidcosociety.service.EmailService;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.util.RandomPasswordGenerateUtil;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class MemberDetailServiceImpl implements MemberDetailService {

    private static final Logger logger = LoggerFactory.getLogger(MemberDetailServiceImpl.class);
    @Autowired
    private MemberDetailDao memberDetailDao;
    @Autowired
    private MemberAccountDao memberAccountDao;
    @Autowired
    private NomineeDao nomineeDao;
    @Autowired
    private CategoryDao categoryDao;
    @Autowired
    private RankDao rankDao;
    @Autowired
    private SectorDao sectorDao;
    @Autowired
    private PostingDao postingDao;
    @Autowired
    private UsersDao usersDao;

    @Autowired
    private UserRoleDao userRoleDao;

    @Autowired
    private RoleDao roleDao;

    @Autowired
    private PaymentModeDao paymentModeDao;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private RdDetailsDao rddetailsdao;

    @Autowired
    private MemberShareDetailDao membersharedetaildao;

    @Autowired
    private MemberShareDetailMonthWiseDao membersharedetailmonthwisedao;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ManageLoanDao manageloandao;

    @Autowired
    private MemberWitnessDao memberwitnessdao;

    @Value("${logopath}")
    private String logopath;

    @Value("${site.url}")
    private String siteurl;

    @Override
    public UpcidResponse addnewMemberDetail(MemberDetailModel memberDetailReq, String remoteaddress, String username) {
        UpcidResponse response = new UpcidResponse();
        try {

            MemberDetail memdetail = null;
            Users users = null;
            String randompassword = "";
            String memeberName = "";
            String memeberEmail = "";
            String PNONumber = "";

            MemberShareDetail membersharedetail = new MemberShareDetail();
            MemberShareDetailMonthWise membersharedetailmonthwise = new MemberShareDetailMonthWise();
            if (memberDetailReq != null && memberDetailReq.getPnoNumber() != null && memberDetailReq.getPnoNumber().trim().length() > 0) {

                MemberDetail memberdetail = memberDetailDao.checkmemberDetail(memberDetailReq.getPnoNumber(),memberDetailReq.getAadharnumber(),memberDetailReq.getPannumber());
                if (memberdetail != null && memberdetail.getMemberId() > 0) {
                    response.setStatus(HttpStatus.CONFLICT);
                    response.setMessage("Member account already exist!");
                    response.setData(memberdetail);
                    return response;
                }
                memdetail = new MemberDetail();
                memeberName = memberDetailReq.getMemberName();
                memdetail.setMemberName(memeberName != null ? memeberName : null);
                memdetail.setDateOfBirth(UtilDate.convertStringToDate(memberDetailReq.getDateOfBirth()));
                memdetail.setDateOfRetirement(UtilDate.convertStringToDate(memberDetailReq.getDateOfRetirement()));
                memdetail.setDateofappoint(UtilDate.convertStringToDate(memberDetailReq.getDateofappoint()));
                memeberEmail = memberDetailReq.getEmail();
                memdetail.setEmail(memeberEmail != null ? memeberEmail : null);
                memdetail.setMobileNumber(memberDetailReq.getMobileNumber());
                memdetail.setFatherName(memberDetailReq.getFatherName());
                PNONumber = memberDetailReq.getPnoNumber();
                memdetail.setPnoNumber(PNONumber != null ? PNONumber : null);
                memdetail.setPresentAddress(memberDetailReq.getPresentAddress());
                memdetail.setPermanentAddress(memberDetailReq.getPermanentAddress());
                memdetail.setProfileulr(memberDetailReq.getProfileulr());
                memdetail.setSignurl(memberDetailReq.getSignurl());
                memdetail.setAccountOpenFormurl(memberDetailReq.getAccountOpenFormurl());
                memdetail.setAccountOpeningDate(UtilDate.convertStringToDate(memberDetailReq.getAccountOpeningDate()));
                memdetail.setAccountstartDate(UtilDate.convertStringToDate(memberDetailReq.getAccountstartDate()));
                memdetail.setMemberaccountNumber(memberDetailReq.getMemberaccountNumber());
                memdetail.setAadharnumber(memberDetailReq.getAadharnumber());
                memdetail.setGpfornpanumber(memberDetailReq.getGpfornpanumber());
                memdetail.setPannumber(memberDetailReq.getPannumber());
                memdetail.setDesclaimer(memberDetailReq.getDesclaimer());
                if(username!=null){
                memdetail.setStatus("Accepted");
                 }else{
                memdetail.setStatus("Pending");
                   }
                memdetail.setCreatedBy(username);
                memdetail.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                memdetail.setModifiedBy(username);
                memdetail.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                memdetail.setIpAddress(remoteaddress);
                MemberAccountModel memberAccountReq = memberDetailReq.getMemberAccountmodel();
                MemberAccount membrAccount = null;
                if (memberAccountReq != null && memberAccountReq.getBankAccountNumber() != null && memberAccountReq.getBankAccountNumber().trim().length() > 0) {
                    membrAccount = new MemberAccount();
                    membrAccount.setBasicPay(memberAccountReq.getBasicPay());
                    membrAccount.setSoceityAccountNumber(memberAccountReq.getBankAccountNumber());
                    membrAccount.setBankAccountNumber(memberAccountReq.getBankAccountNumber());
                    membrAccount.setBankName(memberAccountReq.getBankName());
                    membrAccount.setShareOpeningBal(memberAccountReq.getShareOpeningBal());
                    membrAccount.setSrdAmount(memberAccountReq.getSrdAmount());

                    DateTime date = new DateTime();
                    String month = date.monthOfYear().getAsText();
                    Integer year = null;
                    if (month.equalsIgnoreCase("January") || month.equalsIgnoreCase("February") || month.equalsIgnoreCase("March")) {
                        year = date.getYear() - 1;
                    } else {
                        year = date.getYear();
                    }
                    membersharedetail.setShareOpeningBalance(memberAccountReq.getShareOpeningBal());
                    membersharedetail.setSrdAmount(memberAccountReq.getSrdAmount());
                    membersharedetail.setFinyear(year);

                    membersharedetailmonthwise.setAmount(memberAccountReq.getSrdAmount());
                    membersharedetailmonthwise.setDate(UtilDate.convertStringToDate(memberDetailReq.getAccountOpeningDate()));
                    membersharedetailmonthwise.setMonth(month);

                    membersharedetailmonthwise.setFinyear(year);

                    membrAccount.setProvidentFundNumber(memberAccountReq.getProvidentFundNumber());
                    membrAccount.setLedgerFileNumber(memberAccountReq.getLedgerFileNumber());

                    Category category = categoryDao.getCategoryByid(memberAccountReq.getCategory());
                    if (category != null) {
                        membrAccount.setCategory(category);
                    }
                    Rank rank = rankDao.getRankByid(memberAccountReq.getRank());
                    if (rank != null) {
                        membrAccount.setRank(rank);
                    }
                    Sector sector = sectorDao.getSectorByid(memberAccountReq.getSector());
                    if (sector != null) {
                        membrAccount.setSector(sector);
                    }
                    Posting posting = postingDao.getPostingByid(memberAccountReq.getPosting());
                    if (posting != null) {
                        membrAccount.setPosting(posting);
                    }
                    PaymentMode paymentmode = paymentModeDao.getPaymentmodeById(memberAccountReq.getPaymentId());
                    if (paymentmode != null) {
                        membrAccount.setPaymentmode(paymentmode);
                    }
                } else {

                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("please fill member account information!");
                    response.setData(null);
                    return response;
                }

                MemberAccount memberAccount = memberAccountDao.saveMemberAccount(membrAccount);
                if (memberAccount != null && memberAccount.getAccId() > 0) {
                    memdetail.setMemberAccount(memberAccount);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("member account detail not saved!");
                    response.setData(null);
                    return response;

                }
                
               if(username!=null){
                randompassword = RandomPasswordGenerateUtil.randomAlphaNumeric(6);
                users = new Users();
                users.setUsername(memberDetailReq.getPnoNumber());
                users.setPassword(passwordEncoder.encode(randompassword));
                users.setActive(Boolean.TRUE);
                users.setCreatedBy(username);
                users.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                users.setModifiedBy(username);
                users.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                users.setIpAddress(remoteaddress);
                Users u = usersDao.SaveUsers(users);
                if (u != null && u.getUserid() != null && u.getUserid() > 0) {
                    Role role = roleDao.getroleById(2);
                    if (role != null && role.getRoleid() > 0) {
                        UserRole userRole = new UserRole();
                        userRole.setRole(role);
                        userRole.setUsers(u);
                        userRoleDao.SaveUsersRole(userRole);
                    }
                    memdetail.setUsers(u);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("member registration detail did'n save");
                    response.setData(null);
                    return response;
                }
             }
               
                MemberDetail memberDetail = memberDetailDao.saveMemberDetail(memdetail);
                if (memberDetail != null && memberDetail.getMemberId() > 0) {
                    membersharedetail.setMemberDetail(memberDetail);
                    MemberShareDetail membershardtls = membersharedetaildao.savemeberShareDetail(membersharedetail);
                    if (membershardtls != null && membershardtls.getMsdId() != null && membershardtls.getMsdId() > 0) {
                        membersharedetailmonthwise.setMemberShareDetail(membersharedetail);
                        membersharedetailmonthwisedao.saveNewMemberShareDetailMonthWise(membersharedetailmonthwise);
                    }
                    
                    //save member nominee's detail
                    List<NomineeModel> nomineelst = memberDetailReq.getNomineemodel();
                    if (nomineelst != null && nomineelst.size() > 0) {
                        Nominee nomnee = null;
                        for (NomineeModel nominee : nomineelst) {
                            nomnee = new Nominee();
                            nomnee.setNomineeName(nominee.getNomineeName());
                            nomnee.setPercentage(nominee.getPercentage());
                            nomnee.setRelation(nominee.getRelation());
                            nomnee.setDob(UtilDate.convertStringToDate(nominee.getDob()));
                            nomnee.setAddress(nominee.getRelation());
                            nomnee.setSign(nominee.getSign());

                            nomnee.setMemberDetail(memberDetail);
                            nomineeDao.saveNominee(nomnee);
                        }
                    }
                     //save member witness  detail
                    List<MemberWitnessModel> witnessmodellst = memberDetailReq.getMemberwitnessmodel();
                    if (witnessmodellst != null && !witnessmodellst.isEmpty()) {
                        MemberWitness memberwitness = null;
                        for (MemberWitnessModel memberwitnessmodel : witnessmodellst) {
                            memberwitness = new MemberWitness();
                            memberwitness.setwName(memberwitnessmodel.getwName());
                            memberwitness.setwAddress(memberwitnessmodel.getwAddress());
                            memberwitness.setWmobilenumber(memberwitnessmodel.getWmobilenumber());
                            memberwitness.setwPno(memberwitnessmodel.getwPno());
                            memberwitness.setwRank(memberwitnessmodel.getwRank());
                            memberwitness.setwSignUrl(memberwitnessmodel.getwSignUrl());
                            memberwitness.setMemberDetail(memberDetail);
                            memberwitnessdao.addWitness(memberwitness);
                        }
                    }

                    response.setData(memberDetail);
                    
                   if(username!=null){
                   // this mail will be sent only if member is register by admin side 
                    response = emailService.sendMailToMemeberForAccountOpenning(logopath, siteurl, memeberName, memeberEmail, PNONumber, randompassword);
                   }else{
                    response = emailService.sendMailToMemeberForAccountOpenningFromMemberSide(logopath, memeberName, memeberEmail);
                   }
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Member detail not saved!");
                    response.setData(memberDetail);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("please fill mendatory fields!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when saving member detail");
            logger.info("Exception when saving member detail:" + e);
        }
        return response;

    }
    
     @Override
     public UpcidResponse getAllnewMemberAccountRequestedList(String username){
      UpcidResponse<List<MemberDetailModel>> response = new UpcidResponse();
        try {
            MemberDetailModel mdmodel = null;
            List<MemberDetailModel> mdlst = new ArrayList<>();
            List<MemberDetail> memberdetaillst = memberDetailDao.getAllNewAccountRequestlist("Pending");
            if (memberdetaillst != null && memberdetaillst.size() > 0) {
                for (MemberDetail memberdetail : memberdetaillst) {
                    mdmodel = new MemberDetailModel();
                    mdmodel.setMemberId(memberdetail.getMemberId());
                    mdmodel.setPnoNumber(memberdetail.getPnoNumber());
                    mdmodel.setMemberName(memberdetail.getMemberName());
                    mdmodel.setMobileNumber(memberdetail.getMobileNumber());
                    mdmodel.setAadharnumber(memberdetail.getAadharnumber());
                    mdmodel.setPannumber(memberdetail.getPannumber());
                    mdmodel.setMemberaccountNumber(memberdetail.getMemberaccountNumber());
                    mdmodel.setStatus(memberdetail.getStatus());
                    mdlst.add(mdmodel);
                }
                if (mdlst != null && mdlst.size() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("All member detail!");
                    response.setData(mdlst);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(mdlst);

                }

            } else {

                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(mdlst);

            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting getting All Member detail");
            logger.info("Exception occured when getting All Member detail :" + e);
            e.printStackTrace();
        }
        return response;
         
      }
    

    @Override
    public UpcidResponse getMemberDetailBypnoNumber(String pnonumber, String username) {
        UpcidResponse<MemberDetailModel> response = new UpcidResponse();
        try {
            MemberDetail md = null;
            MemberDetailModel mdmodel = null;
            MemberAccount ma = null;
            MemberAccountModel maModel = null;
            NomineeModel nmodel = null;
            List<NomineeModel> nmodellst = new ArrayList<>();
            List<MemberWitnessModel> witnessmodellist = new ArrayList<>();
            md = memberDetailDao.getmemberDetailByPnoNumber(pnonumber);
            if (md != null && md.getMemberId() > 0) {
                mdmodel = new MemberDetailModel();
                mdmodel.setMemberId(md.getMemberId());
                mdmodel.setPnoNumber(md.getPnoNumber());
                mdmodel.setMemberName(md.getMemberName());
                mdmodel.setMobileNumber(md.getMobileNumber());
                mdmodel.setDateOfBirth(UtilDate.formatetdateToString_dd_MM_yyyy(md.getDateOfBirth()));
                mdmodel.setDateOfRetirement(UtilDate.formatetdateToString_dd_MM_yyyy(md.getDateOfRetirement()));
                mdmodel.setDateofappoint(UtilDate.formatetdateToString_dd_MM_yyyy(md.getDateofappoint()));
                mdmodel.setEmail(md.getEmail());
                mdmodel.setFatherName(md.getFatherName());
                mdmodel.setPermanentAddress(md.getPermanentAddress());
                mdmodel.setPresentAddress(md.getPresentAddress());
                mdmodel.setDesclaimer(md.getDesclaimer());

                mdmodel.setProfileulr(md.getProfileulr());
                mdmodel.setSignurl(md.getSignurl());
                mdmodel.setAccountOpenFormurl(md.getAccountOpenFormurl());

                mdmodel.setAccountOpeningDate(UtilDate.formatetdateToString_dd_MM_yyyy(md.getAccountOpeningDate()));
                mdmodel.setAccountstartDate(UtilDate.formatetdateToString_dd_MM_yyyy(md.getAccountstartDate()));
                mdmodel.setMemberaccountNumber(md.getMemberaccountNumber());
                mdmodel.setAadharnumber(md.getAadharnumber());
                mdmodel.setPannumber(md.getPannumber());
                mdmodel.setGpfornpanumber(md.getGpfornpanumber());
                mdmodel.setDateofappoint(UtilDate.formatetdateToString_dd_MM_yyyy(md.getDateofappoint()));
                //member account detail
                ma = md.getMemberAccount();
                maModel = new MemberAccountModel();
                maModel.setAccId(ma.getAccId());
                maModel.setBasicPay(ma.getBasicPay());
                maModel.setBankName(ma.getBankName());
                maModel.setSrdAmount(ma.getSrdAmount());
                maModel.setSoceityAccountNumber(ma.getSoceityAccountNumber());
                maModel.setBankAccountNumber(ma.getBankAccountNumber());
                maModel.setCategory(ma.getCategory().getCatId());
                maModel.setCategoryName(ma.getCategory().getCategoryName());
                maModel.setRank(ma.getRank().getId());
                maModel.setRankName(ma.getRank().getRank());
                maModel.setSector(ma.getSector().getId());
                maModel.setSectorName(ma.getSector().getSector());
                maModel.setPosting(ma.getPosting().getId());
                maModel.setPostingName(ma.getPosting().getPosting());
                maModel.setSoceityAccountNumber(ma.getSoceityAccountNumber());
                maModel.setPaymentType(ma.getPaymentmode().getPaymentType());
                maModel.setShareOpeningBal(ma.getShareOpeningBal());
                maModel.setLedgerFileNumber(ma.getLedgerFileNumber());
                maModel.setProvidentFundNumber(ma.getProvidentFundNumber());
                mdmodel.setMemberAccountmodel(maModel);

                List<Nominee> nomineelist = nomineeDao.getNomineeBymemberId(md.getMemberId());
                if (nomineelist != null && !nomineelist.isEmpty()) {
                    for (Nominee n : nomineelist) {
                        nmodel = new NomineeModel();
                        nmodel.setId(n.getId());
                        nmodel.setNomineeName(n.getNomineeName());
                        nmodel.setRelation(n.getRelation());
                        nmodel.setDob(UtilDate.formatetdateToString_dd_MM_yyyy(n.getDob()));
                        nmodel.setAddress(n.getAddress());
                        nmodel.setPercentage(n.getPercentage());
                        nmodel.setSign(n.getSign());
                        nmodellst.add(nmodel);
                    }
                }
                mdmodel.setNomineemodel(nmodellst);
                List<MemberWitness> wtlist = memberwitnessdao.getWitnessbymemberID(md.getMemberId());
                if (wtlist != null && !wtlist.isEmpty()) {
                    MemberWitnessModel memberwitnessmodel = null;
                    for (MemberWitness memberwitness : wtlist) {
                        memberwitnessmodel = new MemberWitnessModel();
                        memberwitnessmodel.setwId(memberwitness.getwId());
                        memberwitnessmodel.setwPno(memberwitness.getwPno());
                        memberwitnessmodel.setwName(memberwitness.getwName());
                        memberwitnessmodel.setwRank(memberwitness.getwRank());
                        memberwitnessmodel.setwAddress(memberwitness.getwAddress());
                        memberwitnessmodel.setWmobilenumber(memberwitness.getWmobilenumber());
                        memberwitnessmodel.setwSignUrl(memberwitness.getwSignUrl());
                        witnessmodellist.add(memberwitnessmodel);
                    }

                }
                mdmodel.setMemberwitnessmodel(witnessmodellist);

                if (mdmodel != null && mdmodel.getMemberId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("get member detail by account Number!");
                    response.setData(mdmodel);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Not found!");
                    response.setData(mdmodel);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting Member account detail by Account Number");
            logger.info("Exception occured when getting Member account detail by Account Number:" + e);
            e.printStackTrace();

        }
        return response;
    }

    @Override
    public UpcidResponse getAllMemberDetail(String username) {
        UpcidResponse<List<MemberDetailModel>> response = new UpcidResponse();
        try {
            MemberDetailModel mdmodel = null;
            List<MemberDetailModel> mdlst = new ArrayList<>();
            MemberAccount ma = null;
            MemberAccountModel maModel = null;
            NomineeModel nmodel = null;
//            Users user=null;
            List<NomineeModel> nmodellst = new ArrayList<>();

            List<MemberDetail> memberdetaillst = memberDetailDao.getAllMemberDetail();
            if (memberdetaillst != null && memberdetaillst.size() > 0) {
                for (MemberDetail memberdetail : memberdetaillst) {
                    mdmodel = new MemberDetailModel();
                    mdmodel.setMemberId(memberdetail.getMemberId());
                    mdmodel.setPnoNumber(memberdetail.getPnoNumber());
                    mdmodel.setMemberName(memberdetail.getMemberName());
                    mdmodel.setMobileNumber(memberdetail.getMobileNumber());
                    mdmodel.setDateOfBirth(UtilDate.formatetdateToString_dd_MM_yyyy(memberdetail.getDateOfBirth()));
                    mdmodel.setDateOfRetirement(UtilDate.formatetdateToString_dd_MM_yyyy(memberdetail.getDateOfRetirement()));
                    mdmodel.setEmail(memberdetail.getEmail());
                    mdmodel.setFatherName(memberdetail.getFatherName());
                    mdmodel.setPermanentAddress(memberdetail.getPermanentAddress());
                    mdmodel.setPresentAddress(memberdetail.getPresentAddress());
                    mdmodel.setProfileulr(memberdetail.getProfileulr());
                    mdmodel.setSignurl(memberdetail.getSignurl());
                    mdmodel.setAccountOpenFormurl(memberdetail.getAccountOpenFormurl());
//                    user=new Users();
//                    user.setUsername(memberdetail.getUsers().getUsername());
//                    user.setPassword(memberdetail.getUsers().getPassword());
//                    user.setActive(memberdetail.getUsers().getActive());
                    mdmodel.setUsers(memberdetail.getUsers());
                    //member account detail
                    ma = memberdetail.getMemberAccount();
                    maModel = new MemberAccountModel();
                    maModel.setAccId(ma.getAccId());
                    maModel.setBasicPay(ma.getBasicPay());
                    maModel.setBankName(ma.getBankName());
                    maModel.setSrdAmount(ma.getSrdAmount());
                    maModel.setSoceityAccountNumber(ma.getSoceityAccountNumber());
                    maModel.setBankAccountNumber(ma.getBankAccountNumber());

                    maModel.setCategory(ma.getCategory().getCatId());
                    maModel.setRank(ma.getRank().getId());
                    maModel.setSector(ma.getSector().getId());
                    maModel.setPosting(ma.getPosting().getId());
                    maModel.setSoceityAccountNumber(ma.getSoceityAccountNumber());
                    maModel.setShareOpeningBal(ma.getShareOpeningBal());
                    maModel.setLedgerFileNumber(ma.getLedgerFileNumber());
                    maModel.setProvidentFundNumber(ma.getProvidentFundNumber());
//                Nominee detail list
                    for (Nominee n : memberdetail.getNominee()) {
                        nmodel = new NomineeModel();
                        nmodel.setId(n.getId());
                        nmodel.setNomineeName(n.getNomineeName());
                        nmodel.setRelation(n.getRelation());
                        nmodel.setPercentage(n.getPercentage());
                        nmodellst.add(nmodel);
                    }

                    mdmodel.setMemberAccountmodel(maModel);
                    mdmodel.setNomineemodel(nmodellst);
                    mdlst.add(mdmodel);
                }
                if (mdlst != null && mdlst.size() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("All member detail!");
                    response.setData(mdlst);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(mdlst);

                }

            } else {

                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(mdlst);

            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting getting All Member detail");
            logger.info("Exception occured when getting All Member detail :" + e);
            e.printStackTrace();
        }
        return response;
    }

    
    @Override
    public String getAllMemberDetailforRd(String username) {
        String res = "";
        try {
            Map<String, String> map = new HashMap<>();

            List<MemberDetail> memberdetaillst = memberDetailDao.getAllMemberDetail();
            if (memberdetaillst != null && memberdetaillst.size() > 0) {
                for (MemberDetail memberdetail : memberdetaillst) {
                    map.put(memberdetail.getPnoNumber(), memberdetail.getMemberName() + "[" + memberdetail.getPnoNumber() + "]");
                }
                if (map != null && map.size() > 0) {
                    ObjectMapper mapperObj = new ObjectMapper();
                    res = mapperObj.writeValueAsString(map);

                } else {
                    res = "{}";

                }

            } else {

                res = "{}";

            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return res;
    }

    @Override
    public UpcidResponse getmemberDetailBypnoNumber(String pnoNumber, String username) {
        UpcidResponse<MemberDetailModelforRd> response = new UpcidResponse();
        try {
            MemberDetail memberDetail = null;
            MemberDetailModelforRd memberdetailmodelforrd = null;
            RdDetails rddetails = null;
            memberDetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                memberdetailmodelforrd = new MemberDetailModelforRd();
                memberdetailmodelforrd.setMemberId(memberDetail.getMemberId());
                memberdetailmodelforrd.setPnoNumber(memberDetail.getPnoNumber());
                memberdetailmodelforrd.setMemberName(memberDetail.getMemberName());
                memberdetailmodelforrd.setFatherName(memberDetail.getFatherName());
                memberdetailmodelforrd.setDob(UtilDate.formatetdateToString_dd_MM_yyyy(memberDetail.getDateOfBirth()));
                memberdetailmodelforrd.setPaymentType(memberDetail.getMemberAccount().getPaymentmode().getPaymentType());
                memberdetailmodelforrd.setPosting(memberDetail.getMemberAccount().getPosting().getPosting());
                memberdetailmodelforrd.setRank(memberDetail.getMemberAccount().getRank().getRank());
                memberdetailmodelforrd.setCategory(memberDetail.getMemberAccount().getCategory().getCategoryName());
                memberdetailmodelforrd.setAddress(memberDetail.getPresentAddress());
                rddetails = rddetailsdao.getRdDetailsBymemberId(memberDetail.getMemberId());
                if (rddetails != null && rddetails.getRdAccNo() != null && rddetails.getRdAccNo() > 0) {

                    memberdetailmodelforrd.setRdAccountNo(rddetails.getRdAccNo());
                }
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found");
                response.setData(memberdetailmodelforrd);

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("This PNO number does not exist");
                response.setData(memberdetailmodelforrd);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when updating member detail");
            logger.info("Exception when updating member detail:" + e);

        }
        return response;
    }

    @Override
    public UpcidResponse getmemberDetailBypnoNumberforFD(String pnoNumber, String username) {
        UpcidResponse<MemberDetailModelforRd> response = new UpcidResponse();
        try {
            MemberDetail memberDetail = null;
            MemberDetailModelforRd memberdetailmodelforrd = null;
            memberDetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                memberdetailmodelforrd = new MemberDetailModelforRd();
                memberdetailmodelforrd.setMemberId(memberDetail.getMemberId());
                memberdetailmodelforrd.setPnoNumber(memberDetail.getPnoNumber());
                memberdetailmodelforrd.setMemberName(memberDetail.getMemberName());
                memberdetailmodelforrd.setFatherName(memberDetail.getFatherName());
                memberdetailmodelforrd.setDob(UtilDate.formatetdateToString_dd_MM_yyyy(memberDetail.getDateOfBirth()));
                memberdetailmodelforrd.setPaymentType(memberDetail.getMemberAccount().getPaymentmode().getPaymentType());
                memberdetailmodelforrd.setPosting(memberDetail.getMemberAccount().getPosting().getPosting());
                memberdetailmodelforrd.setRank(memberDetail.getMemberAccount().getRank().getRank());
                memberdetailmodelforrd.setCategory(memberDetail.getMemberAccount().getCategory().getCategoryName());
                memberdetailmodelforrd.setAddress(memberDetail.getPresentAddress());
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found");
                response.setData(memberdetailmodelforrd);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Sorry! member does not exist");
                response.setData(memberdetailmodelforrd);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting member detail for Fd");
            logger.info("Exception when getting member detail for Fd:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse updatenewMemberDetail(MemberDetailModel memberDetailReq, String remoteaddress, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            MemberDetail memberDetail = null;
            MemberAccount memberAccount = null;
            Nominee nominee = null;
            List<Nominee> nomineelst = new ArrayList<>();
//             MemberShareDetail membersharedetail=new MemberShareDetail();
//             MemberShareDetailMonthWise membersharedetailmonthwise= new MemberShareDetailMonthWise();
            if (memberDetailReq != null && memberDetailReq.getMemberId() != null && memberDetailReq.getMemberId() > 0) {
                //check member exist or not if yes then return
                memberDetail = memberDetailDao.checkmemberDetailBymemberIdAndpnonumber(memberDetailReq.getMemberId(), memberDetailReq.getPnoNumber());
                if (memberDetail != null && memberDetail.getMemberId() > 0) {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("member account already exist");
                    response.setData(null);
                    return response;
                }

                memberDetail = memberDetailDao.getmemberDetailBymemeberId(memberDetailReq.getMemberId());
                if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0 && memberDetail.getPnoNumber() != null && memberDetail.getPnoNumber().trim().length() > 0) {

                    memberDetail.setMemberName(memberDetailReq.getMemberName());
                    memberDetail.setDateOfBirth(UtilDate.convertStringToDate(memberDetailReq.getDateOfBirth()));
                    memberDetail.setDateOfRetirement(UtilDate.convertStringToDate(memberDetailReq.getDateOfRetirement()));
                    memberDetail.setEmail(memberDetailReq.getEmail());
                    memberDetail.setFatherName(memberDetailReq.getFatherName());
                    memberDetail.setPnoNumber(memberDetailReq.getPnoNumber());
                    memberDetail.setMobileNumber(memberDetailReq.getMobileNumber());
                    memberDetail.setPresentAddress(memberDetailReq.getPresentAddress());
                    memberDetail.setPermanentAddress(memberDetailReq.getPermanentAddress());
                    
                    memberDetail.setMemberaccountNumber(memberDetailReq.getMemberaccountNumber());
                    memberDetail.setAadharnumber(memberDetailReq.getAadharnumber());
                    memberDetail.setGpfornpanumber(memberDetailReq.getGpfornpanumber());
                    memberDetail.setPannumber(memberDetailReq.getPannumber());
                    memberDetail.setDesclaimer(memberDetailReq.getDesclaimer());
                    if (memberDetailReq.getProfileulr() != null && memberDetailReq.getProfileulr().trim().length() > 0) {
                        memberDetail.setProfileulr(memberDetailReq.getProfileulr());
                    }
                    if (memberDetailReq.getSignurl() != null && memberDetailReq.getSignurl().trim().length() > 0) {
                        memberDetail.setSignurl(memberDetailReq.getSignurl());
                    }
                    if (memberDetailReq.getAccountOpenFormurl() != null && memberDetailReq.getAccountOpenFormurl().trim().length() > 0) {
                        memberDetail.setAccountOpenFormurl(memberDetailReq.getAccountOpenFormurl());
                    }
                   
                    memberDetail.setModifiedBy(username);
                    memberDetail.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    memberDetail.setIpAddress(remoteaddress);
                    
                    
                    
                    
                    
                    
//                    if (memberAccountReq != null && memberAccountReq.getAccId() != null && memberAccountReq.getAccId() > 0 && memberAccountReq.getBankAccountNumber() != null && memberAccountReq.getBankAccountNumber().trim().length() > 0) {
//                        memberAccount = memberAccountDao.checkMemberAccountByaccIdAndBankAccountNumber(memberAccountReq.getAccId(), memberAccountReq.getBankAccountNumber());
//                        if (memberAccount != null && memberAccount.getAccId() != null && memberAccount.getAccId() > 0) {
//                            // check if  duplicate account Number  
//                            response.setStatus(HttpStatus.NOT_FOUND);
//                            response.setMessage("member bank account already exist");
//                            response.setData(null);
//                            return response;
//                        }
                        
                    MemberAccountModel memberAccountReq = memberDetailReq.getMemberAccountmodel();
                        memberAccount = memberAccountDao.getMemberAccountByid(memberAccountReq.getAccId());
                        if (memberAccount != null && memberAccount.getAccId() != null && memberAccount.getAccId() > 0) {
                            memberAccount.setBasicPay(memberAccountReq.getBasicPay());
                            memberAccount.setSoceityAccountNumber(memberAccountReq.getBankAccountNumber());
                            memberAccount.setBankAccountNumber(memberAccountReq.getBankAccountNumber());
                            memberAccount.setBankName(memberAccountReq.getBankName());
                            memberAccount.setShareOpeningBal(memberAccountReq.getShareOpeningBal());
                            memberAccount.setSrdAmount(memberAccountReq.getSrdAmount());
                            memberAccount.setProvidentFundNumber(memberAccountReq.getProvidentFundNumber());
                            memberAccount.setLedgerFileNumber(memberAccountReq.getLedgerFileNumber());
                            
                            Category category = categoryDao.getCategoryByid(memberAccountReq.getCategory());
                            if (category != null) {
                                memberAccount.setCategory(category);
                            }
                            Rank rank = rankDao.getRankByid(memberAccountReq.getRank());
                            if (rank != null) {
                                memberAccount.setRank(rank);
                            }
                            Sector sector = sectorDao.getSectorByid(memberAccountReq.getSector());
                            if (sector != null) {
                                memberAccount.setSector(sector);
                            }
                            Posting posting = postingDao.getPostingByid(memberAccountReq.getPosting());
                            if (posting != null) {
                                memberAccount.setPosting(posting);
                            }
                            
                            MemberShareDetail membersharedetail = membersharedetaildao.getmeberShareDetailBymemberId(memberDetail.getMemberId());
                            if (membersharedetail != null && membersharedetail.getMsdId() != null && membersharedetail.getMsdId() > 0) {
                                membersharedetail.setSrdAmount(memberAccountReq.getSrdAmount());
                                membersharedetaildao.updatemeberShareDetail(membersharedetail);

                            }
                            MemberAccount mA = memberAccountDao.updateMemberAccount(memberAccount);
                            if (mA != null && mA.getAccId() != null && mA.getAccId() > 0) {

                                memberDetail.setMemberAccount(memberAccount);

                            } else {
                                response.setStatus(HttpStatus.NOT_FOUND);
                                response.setMessage("member account detail did'n save");
                                response.setData(null);
                                return response;
                            }

                            //                           usersDao.getUsersById()
                            //update user detial alseo
                            MemberDetail mD = memberDetailDao.saveMemberDetail(memberDetail);
                            if (mD != null && mD.getMemberId() != null && mD.getMemberId() > 0) {

                                List<NomineeModel> nmlst = memberDetailReq.getNomineemodel();
                                if (nmlst != null && nmlst.size() > 0) {
                                    for (NomineeModel nm : nmlst) {
                                        nominee = nomineeDao.getNomineebyId(nm.getId());
                                        if (nominee != null && nominee.getId() != null && nominee.getId() > 0) {
                                            nominee.setNomineeName(nm.getNomineeName());
                                            nominee.setRelation(nm.getRelation());
                                            nominee.setAddress(nm.getAddress());
                                            nominee.setDob(UtilDate.convertStringToDate(nm.getDob()));
                                            if(nm.getSign()!=null){
                                            nominee.setSign(nm.getSign());
                                            }
                                            nominee.setRelation(nm.getRelation());
                                            nominee.setPercentage(nm.getPercentage());
                                            nominee.setMemberDetail(mD);
                                            nomineeDao.updateNominee(nominee);
                                        }

                                    }
                                }
                              List<MemberWitnessModel>witnesslistmodel= memberDetailReq.getMemberwitnessmodel();
                              if(witnesslistmodel!=null && !witnesslistmodel.isEmpty()){
                                 for(MemberWitnessModel witness:witnesslistmodel){
                                  MemberWitness memberwitness=memberwitnessdao.getWitnessbyId(witness.getwId());
                                   if(memberwitness!=null && memberwitness.getwId()>0){
                                     memberwitness.setwName(witness.getwName());
                                     memberwitness.setwAddress(witness.getwAddress());
                                     memberwitness.setwPno(witness.getwPno());
                                     memberwitness.setwRank(witness.getwRank());
                                     if(witness.getwSignUrl()!=null){
                                     memberwitness.setwSignUrl(witness.getwSignUrl());
                                     }
                                     memberwitness.setMemberDetail(mD);
                                     memberwitnessdao.updateWitness(memberwitness);
                                    }
                                  }
                                 }
                              

                                response.setStatus(HttpStatus.OK);
                                response.setMessage("member detail updated!");
                                response.setData(memberDetail);

                            } else {
                                response.setStatus(HttpStatus.NOT_FOUND);
                                response.setMessage("member account detail not update!");
                                response.setData(memberDetail);
                            }
                        } else {
                            response.setStatus(HttpStatus.NOT_FOUND);
                            response.setMessage("member account detail not found!");
                            response.setData(memberDetail);

                        }
                   
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("record not found!");
                    response.setData(memberDetail);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("please fill all mendatory fields!");
                response.setData(memberDetail);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when updating member detail");
            logger.info("Exception when updating member detail:" + e);

        }
        return response;
    }

    @Override
    public UpcidResponse disableMemberDetailByMemeberId(Integer memberId, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            MemberDetail memberDetail = memberDetailDao.getmemberDetailBymemeberId(memberId);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                memberDetail.getUsers().setActive(Boolean.FALSE);
                memberDetail.setModifiedBy(username);
                memberDetail.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                MemberDetail membDetail = memberDetailDao.saveMemberDetail(memberDetail);
                if (membDetail != null && membDetail.getMemberId() != null && membDetail.getMemberId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record disabled successfully!");
                    response.setData(membDetail);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record disable failed!");
                    response.setData(membDetail);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Sorry! record not found");
                response.setData(memberDetail);

            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occurred when disable member");
            logger.info("Exception occurred when disable member:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse InableMemberDetailByMemeberId(Integer memberId, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            MemberDetail memberDetail = memberDetailDao.getmemberDetailBymemeberId(memberId);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                memberDetail.getUsers().setActive(Boolean.TRUE);
                memberDetail.setModifiedBy(username);
                memberDetail.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                MemberDetail membDetail = memberDetailDao.saveMemberDetail(memberDetail);
                if (membDetail != null && membDetail.getMemberId() != null && membDetail.getMemberId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record activate successfully!");
                    response.setData(membDetail);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record activation failed!");
                    response.setData(membDetail);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Sorry! record not found");
                response.setData(memberDetail);

            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occurred when enable member");
            logger.info("Exception occurred when enable member:" + e);
        }
        return response;

    }

    @Override
    public UpcidResponse deleteMemberDetailByMemeberId(Integer memberId, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            MemberDetail memberDetail = memberDetailDao.getmemberDetailBymemeberId(memberId);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                memberDetail.getUsers().setActive(Boolean.FALSE);
                memberDetail.setModifiedBy(username);
                memberDetail.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                memberDetail.setIsDeleted(Boolean.TRUE);
                MemberDetail membDetail = memberDetailDao.saveMemberDetail(memberDetail);

                if (membDetail != null && membDetail.getMemberId() != null && membDetail.getMemberId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("record deleted successfully!");
                    response.setData(membDetail);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("record deletion failed!");
                    response.setData(membDetail);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("record not found!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when delete member detail");
            logger.info("Exception when delete member detail:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getMemberDetailAndSharedetailsformanageloan(String pnoNumber, String username) {
        UpcidResponse<MemberDetailResponseModelForLoan> response = new UpcidResponse();
        try {
            MemberDetail memberDetail = null;
            MemberDetailResponseModelForLoan memberdetailresponsemodelforloan = null;
            memberDetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                LoanDetails loandetails = manageloandao.getloandetailsBymemberId(memberDetail.getMemberId());
                memberdetailresponsemodelforloan = new MemberDetailResponseModelForLoan();
                Double basicpay = memberDetail.getMemberAccount().getBasicPay() != null ? memberDetail.getMemberAccount().getBasicPay() : 0;
                if (loandetails != null) {
                    memberdetailresponsemodelforloan.setLoanLimit(loandetails.getLoanLimit());
                } else {
                    //multiply with multiply from setting need to change
                    memberdetailresponsemodelforloan.setLoanLimit(basicpay * 10);
                }
                memberdetailresponsemodelforloan.setBasicPay(basicpay);
                memberdetailresponsemodelforloan.setMemberaccountNumber(memberDetail.getMemberAccount().getBankAccountNumber());
                memberdetailresponsemodelforloan.setMembermane(memberDetail.getMemberName());
                memberdetailresponsemodelforloan.setPnonumber(memberDetail.getPnoNumber());
                Date date = memberDetail.getDateOfRetirement();
                String retirementdate = "";
                if (date != null) {
                    retirementdate = UtilDate.formatetdateToString_dd_MM_yyyy(date);
                }
                memberdetailresponsemodelforloan.setMemberRetirementDate(retirementdate);
                MemberShareDetail mebersharedetail = membersharedetaildao.getmeberShareDetailBymemberId(memberDetail.getMemberId());
                if (mebersharedetail != null && mebersharedetail.getMsdId() != null && mebersharedetail.getMsdId() > 0) {
                    memberdetailresponsemodelforloan.setTotalShare(mebersharedetail.getTotalShare() != null ? mebersharedetail.getTotalShare() : 0.0);
                }

                response.setStatus(HttpStatus.OK);
                response.setMessage("record found!");
                response.setData(memberdetailresponsemodelforloan);

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("record not found!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting member details for loan!");
            logger.info("Exception when getting member details for loan:" + e);
        }
        return response;
    }
}
