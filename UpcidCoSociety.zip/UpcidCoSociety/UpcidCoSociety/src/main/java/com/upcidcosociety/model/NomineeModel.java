/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
public class NomineeModel {

    private Integer id;

    private String nomineeName;

    private String relation;

    private String dob;

    private String address;

    private String sign;

    private String percentage;
    
   private MultipartFile nomineesign;

    private Integer memberDetail;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomineeName() {
        return nomineeName;
    }

    public void setNomineeName(String nomineeName) {
        this.nomineeName = nomineeName;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    
    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public MultipartFile getNomineesign() {
        return nomineesign;
    }

    public void setNomineesign(MultipartFile nomineesign) {
        this.nomineesign = nomineesign;
    }


    
    public Integer getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(Integer memberDetail) {
        this.memberDetail = memberDetail;
    }

}
