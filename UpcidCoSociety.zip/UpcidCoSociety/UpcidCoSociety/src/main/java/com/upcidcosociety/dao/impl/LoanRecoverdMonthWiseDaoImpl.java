/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.LoanRecoverdMonthWiseDao;
import com.upcidcosociety.dtob.LoanGivenMonthWise;
import com.upcidcosociety.dtob.LoanRecoverdMonthWise;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class LoanRecoverdMonthWiseDaoImpl implements LoanRecoverdMonthWiseDao{
      @Autowired
      private SessionFactory sessionFactory;
    
      @Override
      public LoanRecoverdMonthWise save(LoanRecoverdMonthWise loanrecoverdmonthwise){
        Session session = sessionFactory.getCurrentSession();
        session.save(loanrecoverdmonthwise);
        session.flush();
        return loanrecoverdmonthwise;  
      }
      
      @Override
      public List<LoanRecoverdMonthWise> getAll(Integer loanId,Integer finyear){
       try {
            Session session = sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
            String hql = "FROM LoanRecoverdMonthWise loanrecover WHERE  loanrecover.loandetails.loanId=:loanId AND loanrecover.finyear=:finyear";
            Query query = session.createQuery(hql);
            query.setParameter("loanId", loanId);
            query.setParameter("finyear", finyear);
            List<LoanRecoverdMonthWise> results = query.list();
            if (results != null && results.size() > 0) {
               return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
          return null;
        }
      
      }
}
