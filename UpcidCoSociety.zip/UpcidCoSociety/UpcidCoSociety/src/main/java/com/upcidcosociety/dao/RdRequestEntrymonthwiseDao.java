/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.RdRequestEntrymonthwise;
import com.upcidcosociety.model.MemberRdCuttingModel;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface RdRequestEntrymonthwiseDao {
    
    public List<RdRequestEntrymonthwise> getAllRdRequestEntrymonthwise();
    
    public List<RdRequestEntrymonthwise> getAllRdRequestEntrymonthwiseByrdAccountNumberandSerialNumber(Integer rdAccountNumber,Integer serialNumber);
    
    public RdRequestEntrymonthwise savenewRdRequestEntrymonthwise(RdRequestEntrymonthwise rdrequestentrymonthwise);
    
}
