/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class ChangePasswordModel {
    
    private String CurrentPassword;
    private String newPassword;
    private String confirmNewPassword;

    public ChangePasswordModel() {
    }

    public String getCurrentPassword() {
        return CurrentPassword;
    }

    public void setCurrentPassword(String CurrentPassword) {
        this.CurrentPassword = CurrentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmNewPassword() {
        return confirmNewPassword;
    }

    public void setConfirmNewPassword(String confirmNewPassword) {
        this.confirmNewPassword = confirmNewPassword;
    }

    @Override
    public String toString() {
        return "ChangePasswordModel{" + "CurrentPassword=" + CurrentPassword + ", newPassword=" + newPassword + ", confirmNewPassword=" + confirmNewPassword + '}';
    }
    
    
}
