/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class CategoryController {
    @Autowired
     private CategoryService categoryService;
     @RequestMapping(value = "/category", method = RequestMethod.GET)
     public String category(ModelMap map, HttpServletRequest request, Principal principal){
          map.addAttribute("category_form", new Category());
          map.addAttribute("categoryListRes", categoryService.getAllCategory(principal.getName()));
          return "category";
    }
    
    @RequestMapping(value = "/addcategory", method = RequestMethod.POST)
    public String saveCategory(@ModelAttribute("category_form") Category category, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            map.addAttribute("categoryListRes", categoryService.getAllCategory(principal.getName()));
            return "category";
        } else {
            if (category != null && category.getCatId() != null && category.getCatId() > 0) {
                upcidResponse = categoryService.updateCategory(category,request.getRemoteAddr(),principal.getName());
            } else {
                 upcidResponse = categoryService.addCategory( category,request.getRemoteAddr(),principal.getName());
            }
//            map.addAttribute("catRes", upcidResponse);
        }
         request.getSession().setAttribute("msg", upcidResponse.getMessage());
     
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }
         return "redirect:/upcid/category";
    }
     @RequestMapping(value = "/editcategory/{id}", method = RequestMethod.GET)
     public String editcategory(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<Category> response= categoryService.getCategoryById(id, principal.getName());
        if (response.getStatus() == HttpStatus.OK) {
             map.addAttribute("category_form", response.getData());
             map.addAttribute("categoryListRes", categoryService.getAllCategory(principal.getName()));
            return "category";
        } else {
            return "redirect:/upcid/category";
        }
    }
     
    @RequestMapping(value = "/deletecategory/{id}", method = RequestMethod.GET)
    public String deleteCategory(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
         UpcidResponse<Category> response = categoryService.softDeleteCategoryById(id, principal.getName());
         
//            map.addAttribute("paymentform", apiResponse.getResult());
            request.getSession().setAttribute("msg", response.getMessage());
            if (response.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (response.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");

            } else {
                request.getSession().setAttribute("msgType", "warning");
            }

            return "redirect:/upcid/category";
    }

}
