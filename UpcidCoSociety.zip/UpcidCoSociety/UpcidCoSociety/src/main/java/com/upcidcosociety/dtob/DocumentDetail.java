/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "document_detail")
public class DocumentDetail{
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "docs_id")
  private Long  docId;
  
  @Column(name = "create_date",columnDefinition = "DATE")
  private Date  createdDate;
 
  @Column(name = "docs_url")
  private String  docsurl;

    public DocumentDetail() {
        
    }

  
    public Long getDocId() {
        return docId;
    }

    public void setDocId(Long docId) {
        this.docId = docId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getDocsurl() {
        return docsurl;
    }

    public void setDocsurl(String docsurl) {
        this.docsurl = docsurl;
    }

    @Override
    public String toString() {
        return "DocumentDetail{" + "docId=" + docId + ", createdDate=" + createdDate + ", docsurl=" + docsurl + '}';
    }
  
 
}
