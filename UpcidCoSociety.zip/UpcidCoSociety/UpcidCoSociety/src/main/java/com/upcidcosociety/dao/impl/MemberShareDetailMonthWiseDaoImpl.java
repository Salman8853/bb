/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberShareDetailMonthWiseDao;
import com.upcidcosociety.dtob.MemberShareDetailMonthWise;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberShareDetailMonthWiseDaoImpl implements MemberShareDetailMonthWiseDao{
  @Autowired
  private SessionFactory sessionFactory;
  
  
     @Override
     public MemberShareDetailMonthWise saveNewMemberShareDetailMonthWise(MemberShareDetailMonthWise memberShareDetailMonthWise){ 
        Session session=sessionFactory.getCurrentSession();
        session.save(memberShareDetailMonthWise);
        session.flush();
        return memberShareDetailMonthWise;
     }
      @Override
      public MemberShareDetailMonthWise updateNewMemberShareDetailMonthWise(MemberShareDetailMonthWise memberShareDetailMonthWise){
         try {
           Session session=sessionFactory.getCurrentSession();
           session.update(memberShareDetailMonthWise);
           session.flush();
            return memberShareDetailMonthWise;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
      
       }
     
     @Override
      public List<MemberShareDetailMonthWise> getAllMemberShareDetailMonthWiseBymsdIdAndfinyear(Integer msdId,Integer finYear){
       try {
                           
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM MemberShareDetailMonthWise msdmonthwise WHERE msdmonthwise.memberShareDetail.msdId=:msdId AND msdmonthwise.finyear=:finYear";
               Query query = session.createQuery(hql);
               query.setParameter("msdId",msdId);
               query.setParameter("finYear",finYear);
               List<MemberShareDetailMonthWise>results = query.list();
                if(results!=null && results.size()>0){
                  return results;
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
      
       }
    
}
