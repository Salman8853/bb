package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "loan_details")
public class LoanDetails{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "loan_id")
    private Integer loanId;

    @Column(name = "loanstart_date", columnDefinition = "DATE")
    private Date loanstartDate;

    @Column(name = "loanclose_date", columnDefinition = "DATE")
    private Date loancloseDate;
    
    @Column(name = "principal")
    private Double principal;
    
    @Column(name = "openning_balace")
    private Double openningBalace;
    
    @Column(name = "last_balance")
    private Double lastBalance;
    
    @Column(name = "balace_on_31_march")
    private Double balaceOn31March;

    @Column(name = "loan_limit")
    private Double loanLimit;
    

    @OneToOne
    @JoinColumn(name = "member_id", referencedColumnName = "member_id")
    private MemberDetail memberDetail;

//    @JsonIgnore
//    @OneToMany(mappedBy = "loandetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    private List<LoanGivenMonthWise> loangivenmonthwise;
//    

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }


    public Date getLoanstartDate() {
        return loanstartDate;
    }

    public void setLoanstartDate(Date loanstartDate) {
        this.loanstartDate = loanstartDate;
    }

    public Date getLoancloseDate() {
        return loancloseDate;
    }

    public void setLoancloseDate(Date loancloseDate) {
        this.loancloseDate = loancloseDate;
    }

    public Double getPrincipal() {
        return principal;
    }

    public void setPrincipal(Double principal) {
        this.principal = principal;
    }

    public Double getOpenningBalace() {
        return openningBalace;
    }

    public void setOpenningBalace(Double openningBalace) {
        this.openningBalace = openningBalace;
    }

    public Double getLastBalance() {
        return lastBalance;
    }

    public void setLastBalance(Double lastBalance) {
        this.lastBalance = lastBalance;
    }

    
    public Double getBalaceOn31March() {
        return balaceOn31March;
    }

    public void setBalaceOn31March(Double balaceOn31March) {
        this.balaceOn31March = balaceOn31March;
    }

    public Double getLoanLimit() {
        return loanLimit;
    }

    public void setLoanLimit(Double loanLimit) {
        this.loanLimit = loanLimit;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }

    
}
