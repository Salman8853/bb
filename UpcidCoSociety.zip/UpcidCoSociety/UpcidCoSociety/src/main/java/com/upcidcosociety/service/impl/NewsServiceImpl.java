/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.NewsDao;
import com.upcidcosociety.dtob.News;
import com.upcidcosociety.service.NewsService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class NewsServiceImpl implements NewsService {

    private static final Logger logger = LoggerFactory.getLogger(NewsServiceImpl.class);

    @Autowired
    private NewsDao newsDao;

    @Override
    public UpcidResponse saveNews(News news, String username) {
        UpcidResponse response = new UpcidResponse();
        try {
            News nws = null;
            if (news != null && news.getNewsTitle() != null && news.getNewsDetail() != null && news.getNewsDetail().trim().length() > 0) {
                nws = newsDao.getNewsByTitle(news.getNewsTitle());
                if (nws != null && nws.getId() != null && nws.getId() > 0) {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record already exist with this news title!");
                    response.setData(nws);
                    return response;
                }
                nws = new News();
                nws.setNewsTitle(news.getNewsTitle());
                nws.setCreatedDate(UtilDate.formattedDate(new Date()));
                nws.setNewsDetail(news.getNewsDetail());
                News N = newsDao.saveNews(nws);
                if (N != null && N.getId() != null && N.getId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(N);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(N);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Plaese enter mandatory fields!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving news");
            logger.info("Exception while saving news:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getNewsByTitle(String newsTitle) {
        UpcidResponse response = new UpcidResponse();
        try {
            News nws = null;
            nws = newsDao.getNewsByTitle(newsTitle);
            if (nws != null && nws.getId() != null && nws.getId() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found");
                response.setData(nws);

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(nws);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured during getnews by title");
            logger.info("Exception occured during getnews by title:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getNewsById(Integer id) {
        UpcidResponse<News> response = new UpcidResponse();
        try {
            News nws = null;
            nws = newsDao.getNewsById(id);
            if (nws != null && nws.getId() != null && nws.getId() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found");
                response.setData(nws);

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(nws);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured during getnews by id");
            logger.info("Exception occured during getnews by id:" + e); 
        }
        return response;
    }

    @Override
    public UpcidResponse getAllNews() {
        UpcidResponse<List<News>> response = new UpcidResponse();
        try {
            Date crtdate = UtilDate.formattedDate(new Date());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(crtdate);
            calendar.add(Calendar.DATE, -7);

            Date previousDate = calendar.getTime();
//            String result = dateFormat.format(previousDate);

            List<News> newsList = newsDao.getAllNews(previousDate, crtdate);
            if (newsList != null && newsList.size() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found");
                response.setData(newsList);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found");
                response.setData(newsList);

            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured during get all news");
            logger.info("Exception occured during get all news:" + e);
        }
        return response;
    }

}
