/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import com.upcidcosociety.dao.SmtpConfigurationDao;
import com.upcidcosociety.dtob.SmptConfiguration;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

/**
 *
 * @author m.salman
 */
@Component
public class MailUtil {
   @Autowired
   SmtpConfigurationDao smtpConfigurationDao;
   @Autowired
   JavaMailSenderImpl mailSender;
   private static final Logger logger = LoggerFactory.getLogger(MailUtil.class);
    public JavaMailSender getJavaMailSender() {

            SmptConfiguration smtpConfig = smtpConfigurationDao.getSmtpConfiguration();
//            mailSender=new JavaMailSenderImpl();
            mailSender.setHost(smtpConfig.getHostName());
            mailSender.setPort(smtpConfig.getPort());
            mailSender.setUsername(smtpConfig.getUserName());
            mailSender.setPassword(smtpConfig.getPassword());

            Properties props = mailSender.getJavaMailProperties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", smtpConfig.getSecurityProtocol().equalsIgnoreCase("tls") ? "true" : "false");
            props.put("mail.debug", "true");
            props.put("mail.smtp.ssl.trust", smtpConfig.getHostName());

        return mailSender;
    }

    public String getFromAddr() {
        String frAddr = "";
        try {
            SmptConfiguration smtpConfigs = smtpConfigurationDao.getSmtpConfiguration();
            if (smtpConfigs != null && smtpConfigs.getId()!=null &&smtpConfigs.getId()> 0) {
                frAddr = smtpConfigs.getFromAddress();
            } else {
                frAddr = "From Mail Address Must Not be Blank Or Invalid.";
            }
        } catch (Exception ex) {
            logger.error("Error in mail sending::", ex);
            ex.printStackTrace();
        }
        return frAddr;
    }

//    public Boolean sendMail(String subject, String body, String to, String cc) {
//        Boolean flag = Boolean.FALSE;
//        try {
//            JavaMailSender javaMailSender = getJavaMailSender();
//            if (javaMailSender != null) {
//                MimeMessage message = javaMailSender.createMimeMessage();
//
//                MimeMessageHelper helper = new MimeMessageHelper(message, true);
//                helper.setFrom(getFromAddr());
//                if (cc != null && cc.trim().length() > 0) {
//                    helper.setCc(to);
//                }
//                helper.setTo(to);
////             helper.setTo("sonal@esoftech.in");
//
//                helper.setSubject(subject);
//                helper.setText(body, true);
//                javaMailSender.send(message);
//                logger.info("Mail send successfully to : {} , cc : {} , subject : {} , body : {}", to, cc, subject, body);
//            } else {
//                logger.error("JavaMailSender not found for mail sending !");
//            }
//        } catch (SendFailedException | MailException e) {
//            logger.error("Exception occured while sending mail to : " + to, e);
//        } catch (Exception ex) {
//            logger.error("Exception occured while sending mail to : " + to, ex);
//        }
//        return flag;
//    }
}
