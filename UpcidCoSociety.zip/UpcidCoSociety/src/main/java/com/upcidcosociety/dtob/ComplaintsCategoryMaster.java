/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="complaints_category_master")
public class ComplaintsCategoryMaster {
    
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name = "comp_category_id")
   private Integer compCategoryId;
   
   @Column(name="comp_category_type")
   private String compCategoryType;  
    

    public ComplaintsCategoryMaster() {
        
    }
    public Integer getCompCategoryId() {
        return compCategoryId;
    }

    public void setCompCategoryId(Integer compCategoryId) {
        this.compCategoryId = compCategoryId;
    }

    public String getCompCategoryType() {
        return compCategoryType;
    }

    public void setCompCategoryType(String compCategoryType) {
        this.compCategoryType = compCategoryType;
    }
    
}
