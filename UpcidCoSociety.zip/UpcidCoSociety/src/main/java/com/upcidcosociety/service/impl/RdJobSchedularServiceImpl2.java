/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dao.RdEntryDetailMonthWiseDao;
import com.upcidcosociety.dao.RdRequestEntrymonthwiseDao;
import com.upcidcosociety.dao.RdentryDetailDao;
import com.upcidcosociety.dtob.RdDetails;
import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import com.upcidcosociety.dtob.RdRequestEntrymonthwise;
import com.upcidcosociety.dtob.RdentryDetail;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.upcidcosociety.service.RdJobSchedularService2;

/**
 *
 * @author m.salman
 */

public class RdJobSchedularServiceImpl2 implements RdJobSchedularService2 {

    private static final Logger logger = LoggerFactory.getLogger(RdJobSchedularServiceImpl2.class);

    @Autowired
    private RdDetailsDao rddetailsdao;

    @Autowired
    private RdentryDetailDao rdentrydetaildao;

    @Autowired
    private RdRequestEntrymonthwiseDao rdrequestentrymonthwisedao;

    @Autowired
    private RdEntryDetailMonthWiseDao rdentrydetailmonthwisedao;

    @Override
    public void rdMonthWiseJob() {
            RdentryDetail rdentrydtls = null;
        try {
            List<RdentryDetail> rdentrydetaillist = null;
            Integer memberId = null;
            Map<Integer, Integer> memberMap = new HashMap<>();
            Map<Integer, List<RdRequestEntrymonthwise>> rdserilaMap = null;
            List<RdRequestEntrymonthwise> rdrequestentrymonthwiselst = null;
            Map<Integer, Map<Integer, List<RdRequestEntrymonthwise>>> map = map = new HashMap<>();

            List<RdRequestEntrymonthwise> list = rdrequestentrymonthwisedao.getAllRdRequestEntrymonthwise();

            if (list != null && list.size() > 0) {
                  rdserilaMap = new HashMap<>();
                for (RdRequestEntrymonthwise rdrequestentrymonthwise : list) {
                    memberId = rdrequestentrymonthwise.getMemberId();
                    if ((!rdserilaMap.isEmpty()) && rdserilaMap.containsKey(rdrequestentrymonthwise.getRdaccountno())) {
                        rdserilaMap.get(rdrequestentrymonthwise.getRdaccountno()).add(rdrequestentrymonthwise);
                    } else {
                        rdrequestentrymonthwiselst = new ArrayList<>();
                        rdrequestentrymonthwiselst.add(rdrequestentrymonthwise);
                        rdserilaMap.put(rdrequestentrymonthwise.getRdaccountno(), rdrequestentrymonthwiselst);
                    }
                    memberMap.put(memberId, rdrequestentrymonthwise.getRdaccountno());
                }

            }
            if (!memberMap.isEmpty()) {
                for (Integer memberIds : memberMap.keySet()) {
                    if (rdserilaMap != null && rdserilaMap.containsKey(memberMap.get(memberIds))) {
                        Map<Integer, List<RdRequestEntrymonthwise>> temprdserilaMap = new HashMap<>();
                        temprdserilaMap.put(memberMap.get(memberIds), rdserilaMap.get(memberMap.get(memberIds)));
                        map.put(memberIds, temprdserilaMap);
                    }
                }
            }
            
            List<RdDetails> rddetailsList = rddetailsdao.getAllRdDetails();
            for (RdDetails rddtls : rddetailsList) {
                if (map.containsKey(rddtls.getMemberDetail().getMemberId())) {
                    Map<Integer, List<RdRequestEntrymonthwise>> rdserialNomap = map.get(rddtls.getMemberDetail().getMemberId());

                    if (rdserialNomap != null && rdserialNomap.containsKey(rddtls.getRdAccNo())) {
                        List<RdRequestEntrymonthwise> lst = rdserialNomap.get(rddtls.getRdAccNo());
                        Double netmonthssum = 0.0;
                        Double intdue = 0.0;
                        Double previouseAmmount = 0.0;
                        Double sumassured = 0.0;
                        Double nettotal = 0.0;
                        int month = 0;
                        int totalmonth = 0;
                        for (RdRequestEntrymonthwise rdrequestentrymonthwise : lst) {
                            RdentryDetail rdentrydetail = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdrequestentrymonthwise.getRdserialno());
//                            previouseAmmount = previouseAmmount + rdentrydetail.getOldAmt();
                            List<RdEntryDetailMonthWise> rdentrydetailmonthwiselst = rdentrydetail.getRdEntryDetailMonthWiseList();
                            //get the list of month for each rd

                            List<String> monthList = new ArrayList<>();
                            if (rdentrydetailmonthwiselst != null && rdentrydetailmonthwiselst.size() > 0) {
                                for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdentrydetailmonthwiselst) {
                                    monthList.add(rdentrydetailmonthwise.getMonth());
                                }
                            }
                                 DateTime date = new DateTime();
                            String monthname = date.monthOfYear().getAsText();
                            if (!(monthList.contains(monthname)) && rdrequestentrymonthwise.getMonthName().equals(monthname)) {

                                RdEntryDetailMonthWise Rdentrymonthws = new RdEntryDetailMonthWise();
                                Rdentrymonthws.setMonth(rdrequestentrymonthwise.getMonthName());
                                Rdentrymonthws.setAmount(rdrequestentrymonthwise.getAmount());
                                Rdentrymonthws.setRdEntryDetail(rdentrydetail);
                                rdentrydetailmonthwisedao.saveRdEntryDetailMonthWise(Rdentrymonthws);
                            }
//                                RdentryDetail rdentrydtl = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdentrydetail.getRdSerialNo());
                                
                                for(RdEntryDetailMonthWise rdentrydetailmonthwise:rdentrydetail.getRdEntryDetailMonthWiseList()){
                                    totalmonth++;
                                    if(rdentrydetailmonthwise!=null && rdentrydetailmonthwise.getAmount()>0.0){
                                    netmonthssum = netmonthssum + rdentrydetailmonthwise.getAmount() + previouseAmmount;
                                     month++;
                                     }
                                 }
                                 nettotal = rdentrydetail.getPmd() * 12;
                                if (rdentrydetail != null && rdentrydetail.getPod() == 1) {
                                    
                                    if (rdentrydetail.getStatus().equalsIgnoreCase("close") && (rdentrydetail.getRdDreakingDate().compareTo(new Date())) > 0) {
                                      if(netmonthssum>=nettotal){
                                            for (int i = 1; i <= 12; i++) {
                                                sumassured = sumassured + rdentrydetail.getPmd() * i;
                                            }
                                            intdue = intdue + Math.round(sumassured * 7.5 / 1200);
                                       }else{
                                            for (int i = 1; i <= 12; i++) {
                                                sumassured = sumassured + rdentrydetail.getPmd() * i;
                                            }
                                            intdue = intdue + Math.round(sumassured * 4 / 1200);
                                        }
                                    } else {
//                                  normal rd calculation
                                         for (int i = 1; i <= month; i++) {
                                            sumassured = sumassured + rdentrydetail.getPmd() * i;
                                        }
                                    }
                                        intdue = intdue + Math.round(sumassured * 7.5 / 1200);
                                        rdentrydetail.setResult(netmonthssum + "");
                                        rdentrydetail.setTotalPayment(netmonthssum + intdue);
                                        rdentrydetail.setIntdue(intdue);
                                        rdentrydetaildao.updatenewrdentrydetails(rdentrydetail);
                                }
                        }
                    }

                } else {
//                    if no any request done from member side or admin side for premiume i.e normal deduction from pmd

                    RdDetails rddetails = rddetailsdao.getRdDetailsByrdAccNo(rddtls.getRdAccNo());
                    if (rddetails != null && rddetails.getRdAccNo() != null && rddetails.getRdAccNo() > 0) {
                        Double netmonthssum = 0.0;
                        Double intdue = 0.0;
                        Double previouseAmmount = 0.0;
                        Double sumassured = 0.0;
                        Double nettotal = 0.0;
                        int month = 0;
                        int totalmonth = 0;
                        List<RdentryDetail> rdentrydetaillst = rdentrydetaildao.getAllRdentryDetailsofMember(rddetails.getRdAccNo());

                        if (rdentrydetaillst != null && rdentrydetaillst.size() > 0) {

                            for (RdentryDetail rdentrydetail : rdentrydetaillst) {

                                List<RdEntryDetailMonthWise> Rdentrylst = rdentrydetail.getRdEntryDetailMonthWiseList();
                                List<String> monthList = new ArrayList<>();

                                for (RdEntryDetailMonthWise rdentrydtlsmonthwise : Rdentrylst) {
                                    monthList.add(rdentrydtlsmonthwise.getMonth());
                                }
                                DateTime date = new DateTime();
                                String monthname = date.monthOfYear().getAsText();// get current m onth name 
                                if (!(monthList.isEmpty()) && !(monthList.contains(monthname))) {
                                    RdEntryDetailMonthWise rdentrymonthws = new RdEntryDetailMonthWise();
                                    rdentrymonthws.setAmount(rdentrydetail.getPmd());
                                    rdentrymonthws.setMonth(monthname);
                                    rdentrymonthws.setRdEntryDetail(rdentrydetail);
                                    rdentrydetailmonthwisedao.saveRdEntryDetailMonthWise(rdentrymonthws);
                                }
                                
                                 for(RdEntryDetailMonthWise rdentrydtlsmonthwise:rdentrydetail.getRdEntryDetailMonthWiseList()){
                                    totalmonth++;
                                    if (rdentrydtlsmonthwise != null && rdentrydtlsmonthwise.getAmount() != null && rdentrydtlsmonthwise.getAmount() > 0.0) {
                                        month++;
                                        netmonthssum = netmonthssum + rdentrydtlsmonthwise.getAmount() + previouseAmmount;
                                    }
                                  }
                                nettotal = rdentrydetail.getPmd() * 12;
                                if (rdentrydetail != null && rdentrydetail.getPod() == 1) {
                                    if (rdentrydetail.getStatus().equalsIgnoreCase("close") && (rdentrydetail.getRdDreakingDate().compareTo(new Date())) > 0) {

                                        if (netmonthssum >= nettotal) {

                                            for (int i = 1; i <= 12; i++) {
                                                sumassured = sumassured + rdentrydetail.getPmd() * i;
                                            }
                                            intdue = intdue + Math.round(sumassured * 7.5 / 1200);

                                        } else {
                                            for (int i = 1; i <= 12; i++) {
                                                sumassured = sumassured + rdentrydetail.getPmd() * i;
                                            }
                                            intdue = intdue + Math.round(sumassured * 4 / 1200);
                                        }

                                    } else {

                                        for (int i = 1; i <= month; i++) {
                                            sumassured = sumassured + rdentrydetail.getPmd() * i;
                                        }
                                        intdue = intdue + Math.round(sumassured * 7.5 / 1200);
                                    }

                                    rdentrydetail.setResult(netmonthssum + "");

                                    rdentrydetail.setTotalPayment(netmonthssum + intdue);
                                    rdentrydetail.setIntdue(intdue);
                                    if (totalmonth == 12) {
                                        rdentrydetail.setStatus("close");
                                    }

                                    rdentrydetaildao.updatenewrdentrydetails(rdentrydetail);
                                }
                                
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //rd yearly cron job
    @Override
    public void rdYearlyWiseJob(){
        try {
//         List<RdentryDetail> rdentrydetaillist = null;  
//         List<RdDetails> rddetailsList = rddetailsdao.getAllRdDetails(); 
//         if(rddetailsList!=null && rddetailsList.size()>0){
//         for(RdDetails rd:rddetailsList){
//          rdentrydetaillist= rdentrydetaildao.getAllRdentryDetailsofMember(rd.getRdAccNo());
//          if(rdentrydetaillist!=null && rdentrydetaillist.size()>0){
//         
//          for(RdentryDetail rdentry:rdentrydetaillist){
//             
//           }
//          }
//          
//         }
//       }
            
            System.out.println("yerly job");
        } catch (Exception e) {
        }
    
    
     } 
    
    
    
    
}
