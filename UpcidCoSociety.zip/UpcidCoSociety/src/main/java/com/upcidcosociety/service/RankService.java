/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface RankService {
    public UpcidResponse addranks(Rank rank, String remoteaddress, String username);

    public UpcidResponse updaterank(Rank rank, String remoteaddress, String username);

    public UpcidResponse getAll(String username);
    
   public UpcidResponse getAllrankformember(String user);

    public UpcidResponse getRankById(Integer id, String username);
    
    public UpcidResponse deleteRankById(Integer id, String username);
}
