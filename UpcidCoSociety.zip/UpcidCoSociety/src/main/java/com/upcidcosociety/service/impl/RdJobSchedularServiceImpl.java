/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dao.RdEntryDetailMonthWiseDao;
import com.upcidcosociety.dao.RdRequestEntrymonthwiseDao;
import com.upcidcosociety.dao.RdentryDetailDao;
import com.upcidcosociety.dtob.RdDetails;
import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import com.upcidcosociety.dtob.RdRequestEntrymonthwise;
import com.upcidcosociety.dtob.RdentryDetail;
import com.upcidcosociety.service.RdJobSchedularService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Date;
import org.joda.time.Period;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class RdJobSchedularServiceImpl implements RdJobSchedularService {

    private static final Logger logger = LoggerFactory.getLogger(RdJobSchedularServiceImpl.class);

    @Autowired
    private RdDetailsDao rddetailsdao;

    @Autowired
    private RdentryDetailDao rdentrydetaildao;

    @Autowired
    private RdRequestEntrymonthwiseDao rdrequestentrymonthwisedao;

    @Autowired
    private RdEntryDetailMonthWiseDao rdentrydetailmonthwisedao;

    @Override
    public void rdMonthWiseJob() {
        try {
//        System.out.println("job ----------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>");

            List<RdDetails> rddetailsList = null;
            Map<Integer, List<RdRequestEntrymonthwise>> rdaccountMap = null;
            List<RdRequestEntrymonthwise> rdrequestentrymonthwiselst = null;
            List<RdRequestEntrymonthwise> list = rdrequestentrymonthwisedao.getAllRdRequestEntrymonthwise();
            if (list != null && list.size() > 0) {
                rdaccountMap = new HashMap<>();
                for (RdRequestEntrymonthwise rdrequestentrymonthwise : list) {
                    if ((!rdaccountMap.isEmpty()) && rdaccountMap.containsKey(rdrequestentrymonthwise.getRdaccountno())) {
                        rdaccountMap.get(rdrequestentrymonthwise.getRdaccountno()).add(rdrequestentrymonthwise);
                    } else {
                        rdrequestentrymonthwiselst = new ArrayList<>();
                        rdrequestentrymonthwiselst.add(rdrequestentrymonthwise);
                        rdaccountMap.put(rdrequestentrymonthwise.getRdaccountno(), rdrequestentrymonthwiselst);
                    }
                }
            }

            /**
             * get all rd list of members
             *
             */
            rddetailsList = rddetailsdao.getAllRdDetails();
            if (rddetailsList != null && !rddetailsList.isEmpty()) {
                for (RdDetails rddtls : rddetailsList) {
//                calculate rd month wise here
                    List<RdentryDetail> rdentrylist = rdentrydetaildao.getAllRdentryDetailsofMember(rddtls.getRdAccNo());
                    if (rdentrylist != null && rdentrylist.size() > 0) {
                        List<RdEntryDetailMonthWise> rdmonthList = null;
                        for (RdentryDetail rdentrydetail : rdentrylist) {
                            Double pmd_sum = 0.0;
                            Double pmd = 0.0;
                            Long interestdue = 0l;
                            rdmonthList = rdentrydetail.getRdEntryDetailMonthWiseList();
                            if (rdmonthList != null && rdmonthList.size() > 0) {
                                for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdmonthList) {
                                    pmd_sum = pmd_sum + rdentrydetailmonthwise.getAmount();
                                }
                            }
                            pmd_sum = pmd_sum + rdentrydetail.getOldAmt();
                            Date rdopenningDate = rdentrydetail.getRdOpenningDate();
                            pmd = rdentrydetail.getPmd();
                            if (rdentrydetail.getPod() == 1) {
                                interestdue = RdJobSchedularServiceImpl.calculateRdmonthWise(rdentrydetail.getPod(), 7.5, 4.0, pmd, pmd_sum, rdopenningDate);
                            } else if (rdentrydetail.getPod() == 3) {
                                interestdue = RdJobSchedularServiceImpl.calculateRdmonthWisefor3yr(rdentrydetail.getPod(), 7.5, 4.0, pmd, pmd_sum, rdopenningDate);
                            } else if (rdentrydetail.getPod() == 5) {
                                interestdue = RdJobSchedularServiceImpl.calculateRdmonthWisefor5yr(rdentrydetail.getPod(), 7.5, 4.0, pmd, pmd_sum, rdopenningDate);
                            }
                            RdentryDetail rdentrydetails = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdentrydetail.getRdSerialNo());
                            if (rdentrydetails != null && rdentrydetails.getRdSerialNo() != null && rdentrydetails.getRdSerialNo() > 0) {
                                rdentrydetails.setIntdue(interestdue.doubleValue());
                                rdentrydetails.setIntPaid(0.0);
                                rdentrydetails.setIntBal(0.0);
                                rdentrydetails.setTotalPayment(pmd_sum + interestdue);
                                rdentrydetaildao.updatenewrdentrydetails(rdentrydetails);
                            }
                        }
                    }

                    if (rdaccountMap != null && rdaccountMap.containsKey(rddtls.getRdAccNo())) {
                        List<RdRequestEntrymonthwise> lst = rdaccountMap.get(rddtls.getRdAccNo());
                        Map<Integer, RdRequestEntrymonthwise> rdserianmap = new HashMap<>();
                        for (RdRequestEntrymonthwise rdrequestentrymonthwise : lst) {
                            rdserianmap.put(rdrequestentrymonthwise.getRdserialno(), rdrequestentrymonthwise);
                        }
                        List<RdentryDetail> rdentrylst = rdentrydetaildao.getAllRdentryDetailsofMember(rddtls.getRdAccNo());
                        if (rdentrylst != null && rdentrylst.size() > 0) {
                            for (RdentryDetail rdentrydetail : rdentrylst) {
                                if (rdserianmap.containsKey(rdentrydetail.getRdSerialNo())) {
                                    RdRequestEntrymonthwise rdrequestentrymonthwise = rdserianmap.get(rdentrydetail.getRdSerialNo());
                                    if (rdrequestentrymonthwise != null && rdrequestentrymonthwise.getRdrequestId() != null && rdrequestentrymonthwise.getRdrequestId() > 0) {
                                        List<String> monthList = new ArrayList<>();
                                        for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdentrydetail.getRdEntryDetailMonthWiseList()) {
                                            monthList.add(rdentrydetailmonthwise.getMonth());
                                        }
                                        DateTime date = new DateTime();
                                        String monthname = date.monthOfYear().getAsText();
                                        if (!(monthList.contains(monthname)) && rdrequestentrymonthwise.getMonthName().equals(monthname) && monthList.size() <= rdentrydetail.getPod() * 12) {
                                            RdEntryDetailMonthWise rdentrymonthws = new RdEntryDetailMonthWise();
                                            rdentrymonthws.setMonth(rdrequestentrymonthwise.getMonthName());
                                            rdentrymonthws.setAmount(rdrequestentrymonthwise.getAmount());
                                            rdentrymonthws.setEntryDate(rdrequestentrymonthwise.getCreatedDate() != null ? rdrequestentrymonthwise.getCreatedDate() : new Date());
                                            rdentrymonthws.setRdEntryDetail(rdentrydetail);
                                            rdentrydetailmonthwisedao.saveRdEntryDetailMonthWise(rdentrymonthws);
                                            Double lastmonthamount = 0.0;
                                            RdentryDetail rdentrydetails = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdentrydetail.getRdSerialNo());
                                            if (rdentrydetails != null && rdentrydetails.getRdSerialNo() != null && rdentrydetails.getRdSerialNo() > 0) {
                                                lastmonthamount = rdentrydetails.getTotalPayment();
                                                lastmonthamount = lastmonthamount + rdrequestentrymonthwise.getAmount();
                                                rdentrydetails.setTotalPayment(lastmonthamount);
                                                rdentrydetaildao.updatenewrdentrydetails(rdentrydetails);
                                            }

                                        }
                                    }
                                } else {
                                    List<String> monthList = new ArrayList<>();
                                    for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdentrydetail.getRdEntryDetailMonthWiseList()) {
                                        monthList.add(rdentrydetailmonthwise.getMonth());
                                    }
                                    DateTime date = new DateTime();
                                    String monthname = date.monthOfYear().getAsText();
                                    if (!(monthList.contains(monthname)) && monthList.size() <= (rdentrydetail.getPod() * 12)) {
                                        RdEntryDetailMonthWise rdentrymonthws = new RdEntryDetailMonthWise();
                                        rdentrymonthws.setMonth(monthname);
                                        rdentrymonthws.setAmount(rdentrydetail.getPmd());
                                        rdentrymonthws.setEntryDate(new Date());
                                        rdentrymonthws.setRdEntryDetail(rdentrydetail);
                                        rdentrydetailmonthwisedao.saveRdEntryDetailMonthWise(rdentrymonthws);

                                        Double currentmonthamount = 0.0;
                                        RdentryDetail rdentrydetails = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdentrydetail.getRdSerialNo());
                                        if (rdentrydetails != null && rdentrydetails.getRdSerialNo() != null && rdentrydetails.getRdSerialNo() > 0) {
                                            currentmonthamount = rdentrydetails.getTotalPayment();
                                            currentmonthamount = currentmonthamount + rdentrydetail.getPmd();
                                            rdentrydetails.setTotalPayment(currentmonthamount);
                                            rdentrydetaildao.updatenewrdentrydetails(rdentrydetails);
                                        }
                                    }
                                }

                            }
                        }

                    } else {
                        //if no any request done from member side or admin side for premiume i.e normal deduction from pmd
                        List<RdentryDetail> rdentrydetaillst = rdentrydetaildao.getAllRdentryDetailsofMember(rddtls.getRdAccNo());
                        if (rdentrydetaillst != null && rdentrydetaillst.size() > 0) {
                            for (RdentryDetail rdentrydetail : rdentrydetaillst) {
                                List<String> monthList = new ArrayList<>();
                                List<RdEntryDetailMonthWise> Rdentrymonthwiselst = rdentrydetail.getRdEntryDetailMonthWiseList();
                                for (RdEntryDetailMonthWise rdentrydtlsmonthwise : Rdentrymonthwiselst) {
                                    monthList.add(rdentrydtlsmonthwise.getMonth());
                                }
                                DateTime date = new DateTime();
                                String monthname = date.monthOfYear().getAsText();// get current m onth name 
                                if (!(monthList.contains(monthname)) && monthList.size() <= rdentrydetail.getPod() * 12) {
                                    RdEntryDetailMonthWise rdentrymonthws = new RdEntryDetailMonthWise();
                                    rdentrymonthws.setAmount(rdentrydetail.getPmd());
                                    rdentrymonthws.setMonth(monthname);
                                    rdentrymonthws.setEntryDate(new Date());
                                    rdentrymonthws.setRdEntryDetail(rdentrydetail);
                                    rdentrydetailmonthwisedao.saveRdEntryDetailMonthWise(rdentrymonthws);
                                    Double lastmonthamount=0.0;
                                    RdentryDetail rdentrydetails = rdentrydetaildao.getRdentryDetailsByrdSerialNo(rdentrydetail.getRdSerialNo());
                                    if (rdentrydetails != null && rdentrydetails.getRdSerialNo() != null && rdentrydetails.getRdSerialNo() > 0) {
                                         lastmonthamount =rdentrydetails.getTotalPayment();
                                         lastmonthamount=lastmonthamount+rdentrydetail.getPmd();
                                         rdentrydetails.setTotalPayment(lastmonthamount); 
                                        rdentrydetaildao.updatenewrdentrydetails(rdentrydetails);
                                    }
                                } 
                            }
                        }
                    }//end of else //if no any request done from member side or admin side for premiume i.e normal deduction from pmd

                }// end of RdDetails loop

            }//end of rd Details List

        } catch (Exception e) {
            e.printStackTrace();

        }

    }

    public static Long calculateRdmonthWise(Integer pod, Double rdfullrate, Double rdpartrate, Double pmd, Double net_sum, Date rdopenningdate) {
        Long interestdue = 0l;
        try {
            Double pmd_sum = 0.0;
            Double totalinst = 0.0;
            long totyr = 0;
            Double pmdsum = 0.0, missedinst = 0.0, remmonth = 0.0;
            Date crntdate = new Date();
            Period period = new Period(rdopenningdate.getTime(), crntdate.getTime());
            double totalmonths = period.getYears() * 12 + period.getMonths();
            long months = (long) totalmonths;

            if (pod == 1) {
                totalinst = pmd * 12;
                if (totalmonths >= 12) {
                    if (net_sum >= totalinst) {
                        for (int i = 1; i <= 12; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
//                        interestdue = Math.round(pmdsum * oneYrFullRDIntRate / 1200);
                        interestdue = Math.round(pmdsum * rdfullrate / 1200);
                        System.out.println("interestdue 1 " + interestdue + "<br>");
                    } else {
                        missedinst = totalinst - net_sum;
//                        remmonth = missedinst / pmd;
                        remmonth = Math.floor(missedinst / pmd);
                        months = (long) (totalmonths - remmonth);

                        for (int i = 1; i <= 12; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
//                        interestdue = Math.round(pmdsum * oneYrPartialRDIntRate / 1200);
                        interestdue = Math.round(pmdsum * rdpartrate / 1200);

                        System.out.println("interestdue 2" + interestdue + "<br>");
                    }
                } else if (totalmonths < 12) {
                    if (totalmonths == 0) {
                        interestdue = 0l;
                    } else {
                        try {
                            missedinst = totalinst - net_sum;
                            remmonth = Math.floor(missedinst / pmd);
                            if ((totalmonths + remmonth) == 12) {
                                months = (long) totalmonths;
                            } else {
                                months = (long) (totalmonths - remmonth);
                            }
                        } catch (Exception e) {
                            System.out.print(e);
                        }
                        for (int i = 1; i <= months; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round((pmdsum) * rdpartrate / 1200);
                        System.out.println("interestdue3 " + interestdue + "<br>");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return interestdue;
    }

    public static Long calculateRdmonthWisefor3yr(Integer pod, Double rdfullrate, Double rdpartrate, Double pmd, Double net_sum, Date rdopenningdate) {
        Long interestdue = 0l;
        try {
            Double totalinst = 0.0;
            Double pmdsum = 0.0, missedinst = 0.0, remmonth = 0.0;
            Date crntdate = new Date();
            Period period = new Period(rdopenningdate.getTime(), crntdate.getTime());
            double totalmonths = period.getYears() * 12 + period.getMonths();
            long months = (long) totalmonths;

            if (pod == 3) {
                totalinst = pmd * 36;
                if (totalmonths >= 36) {
                    if (net_sum >= totalinst) {
                        for (int i = 1; i <= 36; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round(pmdsum * rdfullrate / 1200);
//                        System.out.println("interestdue  " + interestdue + "<br>");
                    } else {
                        missedinst = totalinst - net_sum;
//                        remmonth = missedinst / pmd;
                        remmonth = Math.ceil(missedinst / pmd);
                        months = (long) (totalmonths - remmonth);

                        for (int i = 1; i <= 36; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round(pmdsum * rdpartrate / 1200);
//                        System.out.println("interestdue" + interestdue + "<br>");
                    }
                } else {
                    missedinst = totalinst - net_sum;
                    remmonth = Math.ceil(missedinst / pmd);
                    if ((totalmonths + remmonth) == 12) {
                        months = (long) totalmonths;
                    } else {
                        months = (long) (totalmonths - remmonth);
                    }
                    for (int i = 1; i <= months; i++) {
                        pmdsum = pmdsum + pmd * i;
                    }
                    interestdue = Math.round(pmdsum * rdpartrate / 1200);
//                    System.out.println("interestdue  " + interestdue + "<br>");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return interestdue;

    }

    public static Long calculateRdmonthWisefor5yr(Integer pod, Double rdfullrate, Double rdpartrate, Double pmd, Double net_sum, Date rdopenningdate) {
        Long interestdue = 0l;
        try {

            Double totalinst = 0.0;

            Double pmdsum = 0.0, missedinst = 0.0, remmonth = 0.0;
            Date crntdate = new Date();
            Period period = new Period(rdopenningdate.getTime(), crntdate.getTime());
            double totalmonths = period.getYears() * 12 + period.getMonths();
            long months = (long) totalmonths;

            if (pod == 5) {
                totalinst = pmd * 60;
                if (totalmonths >= 60 && net_sum >= totalinst) {
                    if (net_sum >= totalinst) {
                        for (int i = 1; i <= 60; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round(pmdsum * rdfullrate / 1200);
                        System.out.println("interestdue  " + interestdue + "<br>");
                    } else {
                        missedinst = totalinst - net_sum;
//                   remmonth=missedinst/pmd;
                        remmonth = Math.ceil(missedinst / pmd);
                        months = (long) (totalmonths - remmonth);

                        for (int i = 1; i <= 60; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round(pmdsum * rdpartrate / 1200);
                        System.out.println("interestdue" + interestdue + "<br>");
                    }
                } else {
                    if (totalmonths == 0) {
                        interestdue = 0l;
                    } else {
                        missedinst = totalinst - net_sum;
                        remmonth = Math.ceil(missedinst / pmd);
                        months = (long) (totalmonths - remmonth);

                        for (int i = 1; i <= months; i++) {
                            pmdsum = pmdsum + pmd * i;
                        }
                        interestdue = Math.round(pmdsum * rdpartrate / 1200);
                        System.out.println("interestdue  " + interestdue + "<br>");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return interestdue;
    }

}
