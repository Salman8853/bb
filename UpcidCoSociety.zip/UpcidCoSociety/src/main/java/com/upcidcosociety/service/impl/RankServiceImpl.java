/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dao.RankDao;
import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.model.RankModel;
import com.upcidcosociety.service.RankService;
import com.upcidcosociety.util.UpcidConstants;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class RankServiceImpl implements RankService {
  private static final Logger logger = LoggerFactory.getLogger(RankServiceImpl.class);
    @Autowired
    private RankDao rankDao;
    @Autowired
    private MemberAccountDao memberAccountDao;
  
   @Override
   public UpcidResponse addranks(Rank rank,String remoteaddress,String username){
         UpcidResponse response=new UpcidResponse();
         try {
              Rank rk=null;
           if(rank!=null && rank.getRank()!=null &&rank.getRank().trim().length()>0){
                // check that rakk code alreay exist or not  if yes then return otherwise go to next
                rk= rankDao.checkRankByRankname(rank.getRank());
                if(rk!=null && rk.getId()>0){
                   response.setStatus(HttpStatus.CONFLICT);
                   response.setMessage("Record  already exist");
                   response.setData(rk);
                   return response;
                }
               rk =new Rank();
//               rk.setRankCode(rank.getRankCode());
               rk.setRank(rank.getRank());
               rk.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
               rk.setIpAddress(remoteaddress);
               rk.setIsDeleted(Boolean.FALSE);
               Rank rnkres=rankDao.addRank(rk);
               if (rnkres != null && rnkres.getId() > 0) {
                  response.setStatus(HttpStatus.OK);
                   response.setMessage("Record saved");
                   response.setData(rnkres);
               } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Failed");
                   response.setData(rnkres);
               }
           }else{
            response.setStatus(HttpStatus.NOT_FOUND);
           response.setMessage("Please fill mandatory fields");
           response.setData(null);
           }
       } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when adding  new rank");
             logger.info("Exception:" + e);
             e.printStackTrace();
       }
    return response;
   }
   
     @Override
     public UpcidResponse updaterank(Rank rank,String remoteaddress,String username){
        UpcidResponse response=new UpcidResponse();
         try {
             Rank rk=null;
             if(rank!=null && rank.getRank()!=null && rank.getRank().trim().length()>0){
                rk= rankDao.checkRankByidAndRankname(rank.getId(), rank.getRank());
                 if(rk!=null && rk.getId()>0){
                   response.setStatus(HttpStatus.CONFLICT);
                   response.setMessage("Record  already exist");
                   response.setData(rk);
                   return response;
                }
                 rk=rankDao.getRankByid(rank.getId());
                if(rk!=null && rk.getId()!=null && rk.getId()>0){
//                    rk.setRankCode(rank.getRankCode());
                    rk.setRank(rank.getRank());
                    rk.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                    rk.setIpAddress(remoteaddress);
                   Rank rankRes=rankDao.updateRank(rk);
                   if(rankRes!=null && rankRes.getId()>0){
                    response.setStatus(HttpStatus.OK);
                   response.setMessage("Record update successfully!");
                   response.setData(rankRes); 
                   }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record updation failed!");
                   response.setData(rankRes); 
                   }
                 
                }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("Record not found!");
                   response.setData(rk); 
                 }
             }else{
                   response.setStatus(HttpStatus.NOT_FOUND);;
                   response.setMessage("please fill mandatory fields");
                   response.setData(null); 
             }
         } catch (Exception e) {
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when updating rank");
             logger.info("Exception occured when updating rank:" + e);
             e.printStackTrace();
         }
          return response; 
     }
   @Override
    public UpcidResponse getAllrankformember(String user){
           UpcidResponse<List<Rank>> response=new UpcidResponse();
            try {
            List<Rank>rnklst=rankDao.getAllRank();
            if(rnklst!=null && rnklst.size()>0){
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(rnklst);
            }else{
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(rnklst);
             }
            
       } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured whengetAll rank");
             logger.info("Exception occured when getAll Rank:" + e);
             e.printStackTrace();
       }
        return response;
    }
     @Override
    public UpcidResponse getAll(String user){
       UpcidResponse<List<RankModel>> response = new UpcidResponse();
        try {
            RankModel rankModel = null;
            List<RankModel> rankModelList = new ArrayList<>();
            List<Integer> rankIdList = new ArrayList<>();
            List<Rank> rankList = memberAccountDao.getallDistinctRankListListByCriteria();
            if (rankList != null && rankList.size() > 0) {
                for (Rank rnk : rankList) {

                    rankIdList.add(rnk.getId());
                }
            }
              List<Rank>rnklst=rankDao.getAllRank();
            if (rnklst != null && rnklst.size() > 0) {
                for (Rank rank : rnklst) {
                    rankModel = new RankModel();
                    rankModel.setId(rank.getId());
                    rankModel.setRank(rank.getRank());
                    if (rankIdList != null && rankIdList.contains(rank.getId())) {

                        rankModel.setInUse(UpcidConstants.IN_USE);

                    } else {

                        rankModel.setInUse(UpcidConstants.IS_Delete);
                    }
                    rankModelList.add(rankModel);
                }
                response.setStatus(HttpStatus.OK);
                response.setMessage("");
                response.setData(rankModelList);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Not Found");
                response.setData(rankModelList);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getAll rank");
            logger.info("Exception occured while getAll rank:" + e);
            e.printStackTrace();
        }
        return response;
    }

    @Override
    public UpcidResponse getRankById(Integer id,String user) {
        UpcidResponse<Rank> response = new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Rank rank = rankDao.getRankByid(id);
                if (rank != null && rank.getId() > 0) {
                     response.setStatus(HttpStatus.OK);
                    response.setMessage("");
                    response.setData(rank);
                } else {
                      response.setStatus(HttpStatus.OK);
                    response.setMessage("Record not found!");
                    response.setData(rank);
                }
            } else {
                response.setStatus(HttpStatus.OK);
                response.setMessage("rank id not found!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when get rank by id");
            logger.info("Exception occured whilewhen get rank by id:" + e);
            e.printStackTrace();
        }
        return response;
    }
    @Override
     public UpcidResponse deleteRankById(Integer id, String username){
            UpcidResponse<Rank> response = new UpcidResponse();
        try {
            if (id != null && id > 0) {
                Rank rank = rankDao.getRankByid(id);
                if (rank != null && rank.getId() > 0) {
                     rank.setIsDeleted(Boolean.TRUE);
                     rank.setModifiedBy(username);
                     rank.setModifiedDate(UtilDate.convertDatetoTimestamp(new Date()));
                     Rank rnk= rankDao.updateRank(rank);
                     if(rnk!=null &&rnk.getId()!=null&&rnk.getId()>0){
                      response.setStatus(HttpStatus.OK);
                      response.setMessage("Record Deleted!");
                      response.setData(rank);
                      }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record Deletiton failed!");
                    response.setData(rank);
                   }
                } else {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record does not exist!");
                    response.setData(rank);
                }
            } else {
                response.setStatus(HttpStatus.OK);
                response.setMessage("rank id not found!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when delete rank by id");
            logger.info("Exception occured when delete rank by id:" + e);
            e.printStackTrace();
        }
        return response;
         
     }

}
