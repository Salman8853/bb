/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.model.MemberDetailModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface MemberDetailService {

    public UpcidResponse addnewMemberDetail(MemberDetailModel memberDetailReq, String remoteaddress, String username);

    public UpcidResponse updatenewMemberDetail(MemberDetailModel memberDetailReq, String remoteaddress, String username);

    public UpcidResponse getMemberDetailBypnoNumber(String pnoNumber, String username);
    
    public UpcidResponse getAllnewMemberAccountRequestedList(String username);

    public UpcidResponse deleteMemberDetailByMemeberId(Integer memberId, String username);

    public UpcidResponse disableMemberDetailByMemeberId(Integer memberId, String username);

    public UpcidResponse InableMemberDetailByMemeberId(Integer memberId, String username);

    public UpcidResponse getAllMemberDetail(String username);

    public String getAllMemberDetailforRd(String username);

    public UpcidResponse getmemberDetailBypnoNumber(String pnoNumber, String username);

    public UpcidResponse getmemberDetailBypnoNumberforFD(String pnoNumber, String username);
    
    public UpcidResponse getMemberDetailAndSharedetailsformanageloan(String pnoNumber,String username);
}
