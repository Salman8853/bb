/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dtob.RdDetails;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RdDetailsDaoImpl implements RdDetailsDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public RdDetails saveNewRdDetails(RdDetails rdDetails) {
        Session session = sessionFactory.getCurrentSession();
        session.save(rdDetails);
        session.flush();
        return rdDetails;
    }

    @Override
    public RdDetails getRdDetailsByrdAccNo(Integer rdAccNo) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM RdDetails rd WHERE  rd.rdAccNo=:rdAccNo";
            Query query = session.createQuery(hql);
            query.setParameter("rdAccNo", rdAccNo);
            List<RdDetails> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public RdDetails getRdDetailsBymemberId(Integer memberId) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM RdDetails rd WHERE  rd.memberDetail.memberId=:memberId";
            Query query = session.createQuery(hql);
            query.setParameter("memberId", memberId);
            List<RdDetails> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
      @Override
      public List<RdDetails> getAllRdDetails(){
       List<RdDetails> list = sessionFactory.getCurrentSession()
                .createCriteria(RdDetails.class)
                .add(Restrictions.eq("active", Boolean.TRUE))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
      
       
}
