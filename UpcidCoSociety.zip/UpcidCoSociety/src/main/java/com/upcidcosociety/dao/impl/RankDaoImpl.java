/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;
import com.upcidcosociety.dao.RankDao;
import com.upcidcosociety.dtob.Rank;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RankDaoImpl implements RankDao {
  @Autowired
  private SessionFactory sessionFactory;
    
     @Override
     public Rank addRank(Rank rank){
         Session session = sessionFactory.getCurrentSession();
         session.save(rank);
         session.flush();
         return rank;
     }
    @Override
    public Rank updateRank(Rank rank){
        try {
           Session session = sessionFactory.getCurrentSession();
           session.update(rank);
           session.flush();
            return rank;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
     }
    @Override
    public Rank getRankByid(Integer id) {

         try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM Rank rnk WHERE rnk.isDeleted!=TRUE AND rnk.id=:id";
         Query query = session.createQuery(hql);
         query.setParameter("id",id);
         List<Rank> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }

    }
    @Override
     public Rank checkRankByRankname(String rankName){
      try {
        Session session = sessionFactory.getCurrentSession();
       String hql = "FROM Rank rnk WHERE rnk.isDeleted !=TRUE AND rnk.rank=:rankname";
       Query query = session.createQuery(hql);
       query.setParameter("rankname", rankName);
       List<Rank> results = query.list();     
       return  results.get(0);
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
     }
    
    @Override
    public Rank checkRankByidAndRankname(Integer Id,String rankName){
        try {
       Session session=sessionFactory.getCurrentSession();
       String hql = "FROM Rank rnk WHERE rnk.isDeleted!=TRUE  AND rnk.id!=:Id AND rnk.rank=:rankname";
       Query query = session.createQuery(hql);
       query.setParameter("Id", Id);
       query.setParameter("rankname", rankName);
       List<Rank> results = query.list();     
       return  results.get(0);
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    
    @Override
   public List<Rank> getAllRank(){
       
     List<Rank> list =sessionFactory.getCurrentSession()
				.createCriteria(Rank.class)
				.add(Restrictions.eq("isDeleted", Boolean.FALSE))
				.list();
		if(!list.isEmpty() ) {
		return list;
		}
		return null;
   }
   
   
}
