/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberShareRequestDao;
import com.upcidcosociety.dtob.MemberShareRequest;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberShareRequestDaoImpl implements MemberShareRequestDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public MemberShareRequest save(MemberShareRequest membersharerequest) {
        Session session = sessionFactory.getCurrentSession();
        session.save(membersharerequest);
        session.flush();
        return membersharerequest;

    }

    @Override
    public MemberShareRequest getmemberRequestListBymemberId(Integer memberId, String monthname) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberShareRequest request WHERE request.memberId=:memberId AND request.month=:monthname";
            Query query = session.createQuery(hql);
            query.setParameter("memberId", memberId);
            query.setParameter("monthname", monthname);
            List<MemberShareRequest> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public List<MemberShareRequest> getAllmemberRequestListforcrntmonth(Date sdate, Date edate) {
        try {
            List<MemberShareRequest> list = sessionFactory.getCurrentSession()
                    .createCriteria(MemberShareRequest.class)
                    .add(Restrictions.ge("date", sdate))
                    .add(Restrictions.le("date", edate))
                    .list();
            if (!list.isEmpty()) {
                return list;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
