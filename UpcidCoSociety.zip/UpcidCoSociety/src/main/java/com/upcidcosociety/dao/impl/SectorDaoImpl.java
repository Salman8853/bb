/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.SectorDao;
import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.dtob.Sector;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class SectorDaoImpl implements SectorDao{
  @Autowired
  private SessionFactory sessionFactory;
    
    @Override
    public Sector addSector(Sector sector){
        Session session=sessionFactory.getCurrentSession();
        session.save(sector);
        session.flush();
        return sector;
    }
    
    @Override
    public Sector updateSector(Sector sector){
         try {
           Session session=sessionFactory.getCurrentSession();
                   session.update(sector);
	           session.flush();
            return sector;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
   
    @Override
    public Sector getSectorByid(Integer id){
      try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM Sector sect WHERE sect.isDeleted!=TRUE AND sect.id=:id";
         Query query = session.createQuery(hql);
         query.setParameter("id",id);
         List<Sector> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
    }
    
    @Override
    public Sector checkSectorBysector(String sector){
         try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM Sector sect WHERE sect.isDeleted!=TRUE AND sect.sector=:sector";
               Query query = session.createQuery(hql);
               query.setParameter("sector",sector);
               List<Sector>results = query.list();
                if(results!=null && results.size()>0){
                  return results.get(0);
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
    }
    
    @Override
     public Sector checkSectorByidAndSector(Integer id,String sector){
        try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "FROM Sector sect WHERE sect.isDeleted!=TRUE AND sect.id!=:id AND sect.sector=:sector";
               Query query = session.createQuery(hql);
               query.setParameter("id",id);
               query.setParameter("sector",sector);
               List<Sector>results = query.list();
                if(results!=null && results.size()>0){
                  return results.get(0);
                  }else{
                   return null;
                  }
             } catch (Exception e) {
                e.printStackTrace();
                return null; 
           }
     
     }
    
    @Override
    public List<Sector> getAllSector(){
     List<Sector> list = sessionFactory.getCurrentSession()
                .createCriteria(Sector.class)
                .add(Restrictions.eq("isDeleted", Boolean.FALSE))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    
    }
}
