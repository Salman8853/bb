/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.PageMasterDao;
import com.upcidcosociety.dtob.PageMaster;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class PageMasterDaoImpl implements PageMasterDao {
    
  @Autowired
  private SessionFactory sessionFactory;
  
    @Override
     public PageMaster getPageMasterBypageName(String pageName){
         
         try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM PageMaster pm WHERE pm.pageName=:pageName";
         Query query = session.createQuery(hql);
         query.setParameter("pageName",pageName);
         List<PageMaster> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
     }
     
    @Override
    public PageMaster getPageMasterBypageId(Integer pageId){
         try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM PageMaster pm WHERE pm.pid=:pageId";
         Query query = session.createQuery(hql);
         query.setParameter("pageId",pageId);
         List<PageMaster> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
    }
}
