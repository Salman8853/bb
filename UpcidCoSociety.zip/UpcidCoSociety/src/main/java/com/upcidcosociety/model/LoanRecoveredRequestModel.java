/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class LoanRecoveredRequestModel {
    private Boolean iscrntMonth;
    
    private Double janValue;

    private Double febValue;

    private Double marchValue;

    private Double aprilValue;

    private Double mayValue;

    private Double juneValue;

    private Double julyValue;

    private Double augustValue;

    private Double septValue;

    private Double octValue;

    private Double novValue;

    private Double decValue;

    public Boolean getIscrntMonth() {
        return iscrntMonth;
    }

    public void setIscrntMonth(Boolean iscrntMonth) {
        this.iscrntMonth = iscrntMonth;
    }
 
    public Double getJanValue() {
        return janValue;
    }

    public void setJanValue(Double janValue) {
        this.janValue = janValue;
    }

    public Double getFebValue() {
        return febValue;
    }

    public void setFebValue(Double febValue) {
        this.febValue = febValue;
    }

    public Double getMarchValue() {
        return marchValue;
    }

    public void setMarchValue(Double marchValue) {
        this.marchValue = marchValue;
    }

    public Double getAprilValue() {
        return aprilValue;
    }

    public void setAprilValue(Double aprilValue) {
        this.aprilValue = aprilValue;
    }

    public Double getMayValue() {
        return mayValue;
    }

    public void setMayValue(Double mayValue) {
        this.mayValue = mayValue;
    }

    public Double getJuneValue() {
        return juneValue;
    }

    public void setJuneValue(Double juneValue) {
        this.juneValue = juneValue;
    }

    public Double getJulyValue() {
        return julyValue;
    }

    public void setJulyValue(Double julyValue) {
        this.julyValue = julyValue;
    }

    public Double getAugustValue() {
        return augustValue;
    }

    public void setAugustValue(Double augustValue) {
        this.augustValue = augustValue;
    }

    public Double getSeptValue() {
        return septValue;
    }

    public void setSeptValue(Double septValue) {
        this.septValue = septValue;
    }

    public Double getOctValue() {
        return octValue;
    }

    public void setOctValue(Double octValue) {
        this.octValue = octValue;
    }

    public Double getNovValue() {
        return novValue;
    }

    public void setNovValue(Double novValue) {
        this.novValue = novValue;
    }

    public Double getDecValue() {
        return decValue;
    }

    public void setDecValue(Double decValue) {
        this.decValue = decValue;
    }
    
    

}
