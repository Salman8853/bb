/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class CategoryModel {
 private Integer catId;
 
 private String categoryName;
 
 private String InUse;

    public CategoryModel() {
        
    }
 

    public Integer getCatId() {
        return catId;
    }

    public void setCatId(Integer catId) {
        this.catId = catId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getInUse() {
        return InUse;
    }

    public void setInUse(String InUse) {
        this.InUse = InUse;
    }

    @Override
    public String toString() {
        return "CategoryModel{" + "catId=" + catId + ", categoryName=" + categoryName + ", InUse=" + InUse + '}';
    }
 
}
