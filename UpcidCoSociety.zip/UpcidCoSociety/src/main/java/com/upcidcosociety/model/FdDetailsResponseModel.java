/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class FdDetailsResponseModel {
    
 private String pnoNumber;

 private String fdAccNo;

 private String openningDate; 
 
 private Integer fdPeriod;  
  
 private String fdStatus;
   
 private Double openningDeposite;

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public String getFdAccNo() {
        return fdAccNo;
    }

    public void setFdAccNo(String fdAccNo) {
        this.fdAccNo = fdAccNo;
    }

    public String getOpenningDate() {
        return openningDate;
    }

    public void setOpenningDate(String openningDate) {
        this.openningDate = openningDate;
    }

    public Integer getFdPeriod() {
        return fdPeriod;
    }

    public void setFdPeriod(Integer fdPeriod) {
        this.fdPeriod = fdPeriod;
    }

    public String getFdStatus() {
        return fdStatus;
    }

    public void setFdStatus(String fdStatus) {
        this.fdStatus = fdStatus;
    }

    public Double getOpenningDeposite() {
        return openningDeposite;
    }

    public void setOpenningDeposite(Double openningDeposite) {
        this.openningDeposite = openningDeposite;
    }

   
}
