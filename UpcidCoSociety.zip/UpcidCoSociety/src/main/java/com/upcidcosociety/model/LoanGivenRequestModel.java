/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class LoanGivenRequestModel {
    private String iscrnjantMonth="True";
    private String iscrntfebMonth="True";
    private String iscrntmarMonth="True";
    private String iscrntaprMonth="True";
    private String iscrntmayMonth="True";
    private String iscrntjuneMonth="True";
    private String iscrntjulyMonth="True";
    private String iscrntaugMonth="True";
    private String iscrntseptMonth="True";
    private String iscrntoctMonth="True";
    private String iscrntnovMonth="True";
    private String iscrntdecMonth="True";

    private String monthName;
    
    private Double janValue;

    private Double febValue;

    private Double marchValue;

    private Double aprilValue;

    private Double mayValue;

    private Double juneValue;

    private Double julyValue;

    private Double augustValue;

    private Double septValue;

    private Double octValue;

    private Double novValue;

    private Double decValue;

    public String getIscrnjantMonth() {
        return iscrnjantMonth;
    }

    public void setIscrnjantMonth(String iscrnjantMonth) {
        this.iscrnjantMonth = iscrnjantMonth;
    }

  

    public String getIscrntfebMonth() {
        return iscrntfebMonth;
    }

    public void setIscrntfebMonth(String iscrntfebMonth) {
        this.iscrntfebMonth = iscrntfebMonth;
    }

    public String getIscrntmarMonth() {
        return iscrntmarMonth;
    }

    public void setIscrntmarMonth(String iscrntmarMonth) {
        this.iscrntmarMonth = iscrntmarMonth;
    }

    public String getIscrntaprMonth() {
        return iscrntaprMonth;
    }

    public void setIscrntaprMonth(String iscrntaprMonth) {
        this.iscrntaprMonth = iscrntaprMonth;
    }

    public String getIscrntmayMonth() {
        return iscrntmayMonth;
    }

    public void setIscrntmayMonth(String iscrntmayMonth) {
        this.iscrntmayMonth = iscrntmayMonth;
    }

    public String getIscrntjuneMonth() {
        return iscrntjuneMonth;
    }

    public void setIscrntjuneMonth(String iscrntjuneMonth) {
        this.iscrntjuneMonth = iscrntjuneMonth;
    }

    public String getIscrntjulyMonth() {
        return iscrntjulyMonth;
    }

    public void setIscrntjulyMonth(String iscrntjulyMonth) {
        this.iscrntjulyMonth = iscrntjulyMonth;
    }

    public String getIscrntaugMonth() {
        return iscrntaugMonth;
    }

    public void setIscrntaugMonth(String iscrntaugMonth) {
        this.iscrntaugMonth = iscrntaugMonth;
    }

    public String getIscrntseptMonth() {
        return iscrntseptMonth;
    }

    public void setIscrntseptMonth(String iscrntseptMonth) {
        this.iscrntseptMonth = iscrntseptMonth;
    }

    public String getIscrntoctMonth() {
        return iscrntoctMonth;
    }

    public void setIscrntoctMonth(String iscrntoctMonth) {
        this.iscrntoctMonth = iscrntoctMonth;
    }

    public String getIscrntnovMonth() {
        return iscrntnovMonth;
    }

    public void setIscrntnovMonth(String iscrntnovMonth) {
        this.iscrntnovMonth = iscrntnovMonth;
    }

    public String getIscrntdecMonth() {
        return iscrntdecMonth;
    }

    public void setIscrntdecMonth(String iscrntdecMonth) {
        this.iscrntdecMonth = iscrntdecMonth;
    }
    
    

    public String getMonthName() {
        return monthName;
    }

    public void setMonthName(String monthName) {
        this.monthName = monthName;
    }
   
    
    public Double getJanValue() {
        return janValue;
    }

    public void setJanValue(Double janValue) {
        this.janValue = janValue;
    }

    public Double getFebValue() {
        return febValue;
    }

    public void setFebValue(Double febValue) {
        this.febValue = febValue;
    }

    public Double getMarchValue() {
        return marchValue;
    }

    public void setMarchValue(Double marchValue) {
        this.marchValue = marchValue;
    }

    public Double getAprilValue() {
        return aprilValue;
    }

    public void setAprilValue(Double aprilValue) {
        this.aprilValue = aprilValue;
    }

    public Double getMayValue() {
        return mayValue;
    }

    public void setMayValue(Double mayValue) {
        this.mayValue = mayValue;
    }

    public Double getJuneValue() {
        return juneValue;
    }

    public void setJuneValue(Double juneValue) {
        this.juneValue = juneValue;
    }

    public Double getJulyValue() {
        return julyValue;
    }

    public void setJulyValue(Double julyValue) {
        this.julyValue = julyValue;
    }

    public Double getAugustValue() {
        return augustValue;
    }

    public void setAugustValue(Double augustValue) {
        this.augustValue = augustValue;
    }

    public Double getSeptValue() {
        return septValue;
    }

    public void setSeptValue(Double septValue) {
        this.septValue = septValue;
    }

    public Double getOctValue() {
        return octValue;
    }

    public void setOctValue(Double octValue) {
        this.octValue = octValue;
    }

    public Double getNovValue() {
        return novValue;
    }

    public void setNovValue(Double novValue) {
        this.novValue = novValue;
    }

    public Double getDecValue() {
        return decValue;
    }

    public void setDecValue(Double decValue) {
        this.decValue = decValue;
    }
    
    

}
