/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.LoanDetails;
import com.upcidcosociety.model.LoanRequestModel;
import com.upcidcosociety.model.MemberDetailResponseModelForLoan;
import com.upcidcosociety.service.ManageLoanService;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class ManageLoanController {

    @Autowired
    private MemberDetailService memberDetailService;

    @Autowired
    private ManageLoanService manageloanservice;

    @RequestMapping(value = "/manageloan", method = RequestMethod.GET)
    public String manageloan(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailResponseModelForLoan> response = new UpcidResponse();
        MemberDetailResponseModelForLoan memberdetailforloan = new MemberDetailResponseModelForLoan();
        response.setData(memberdetailforloan);
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setMessage(null);
        map.addAttribute("membedetailforloan", response);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("loan_form", new LoanRequestModel());
        return "manageloan";
    }

    @RequestMapping(value = "/manageloan/{pnonumber}", method = RequestMethod.GET)
    public String manageloandetail(@PathVariable String pnonumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<LoanRequestModel> response = null;
         map.addAttribute("membedetailforloan", memberDetailService.getMemberDetailAndSharedetailsformanageloan(pnonumber, principal.getName()));
        response = manageloanservice.getloandetailbymemberId(pnonumber, principal.getName());
        map.addAttribute("loan_form", response.getData());
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        return "manageloan";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveloanData(@ModelAttribute("loan_form") LoanRequestModel loanrequestmodel, BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
         UpcidResponse<LoanDetails> upcidResponse = new UpcidResponse();
        if (result.hasErrors()) {
            return "manageloan";
        } else {
            if (loanrequestmodel != null && loanrequestmodel.getLoanId() != null && loanrequestmodel.getLoanId() > 0) {
//           Write service for loan update
              upcidResponse = manageloanservice.updateloandetail(loanrequestmodel, principal.getName());
            } else {
              upcidResponse = manageloanservice.saveloandetail(loanrequestmodel, principal.getName());
            }
            request.getSession().setAttribute("msg", upcidResponse.getMessage());
            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/manageloan/" + loanrequestmodel.getPnoNumber();
        }

    }
}
